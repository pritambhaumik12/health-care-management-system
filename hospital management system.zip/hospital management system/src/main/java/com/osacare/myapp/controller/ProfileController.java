package com.osacare.myapp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.osacare.myapp.entity.User;
import com.osacare.myapp.service.HospitalDetailsService;
import com.osacare.myapp.service.ProfileService;
import com.osacare.myapp.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class ProfileController {

    private final ProfileService profileService;
    private final UserService userService;
    private final HospitalDetailsService hospitalDetailsService;

    public ProfileController(ProfileService profileService, UserService userService, HospitalDetailsService hospitalDetailsService) {
        this.profileService = profileService;
        this.userService = userService;
        this.hospitalDetailsService = hospitalDetailsService;
    }

    @GetMapping("/patient/setup")
    public String patientSetupForm(HttpSession session) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null || !"Patient".equalsIgnoreCase(user.getRole())) {
            return "redirect:/login";
        }
        return "patient/setup";
    }

    @PostMapping("/patient/setup")
    public String patientSetupSubmit(
            @RequestParam(required = false) Integer birthYear,
            @RequestParam(required = false) String gender,
            @RequestParam(required = false) String bloodGroup,
            @RequestParam(required = false) String address,
            @RequestParam(required = false) String nationalIdName,
            @RequestParam(required = false) String nationalIdNumber,
            @RequestParam(required = false) String emergencyContactName,
            @RequestParam(required = false) String emergencyContactNumber,
            @RequestParam(required = false) String emergencyContactAddress,
            @RequestParam(required = false) String chiefComplaint,
            @RequestParam(required = false) String illnessHistory,
            @RequestParam(required = false) String surgicalHistory,
            @RequestParam(required = false) String allergies,
            @RequestParam(required = false) String familyHistory,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) {
            return "redirect:/login";
        }

        // We use the base username as the system sync ID
        String patientIdNumber = user.getUsername();

        if (profileService.createPatientProfile(
                user, patientIdNumber, birthYear, gender, bloodGroup, 
                address, nationalIdName, nationalIdNumber, 
                emergencyContactName, emergencyContactNumber, emergencyContactAddress,
                chiefComplaint, illnessHistory, surgicalHistory, allergies, familyHistory) != null) {
            
            redirectAttributes.addFlashAttribute("success", "Profile setup successfully!");
            return "redirect:/dashboard"; 
        }

        redirectAttributes.addFlashAttribute("error", "Profile already exists or could not be created.");
        return "redirect:/patient/setup"; 
    }

    @GetMapping("/doctor/setup")
    public String doctorSetupForm(HttpSession session) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null || !"Doctor".equalsIgnoreCase(user.getRole())) {
            return "redirect:/login";
        }
        return "doctor/setup";
    }

    @PostMapping("/doctor/setup")
    public String doctorSetupSubmit(
            @RequestParam String department,
            @RequestParam String medicalLicenseNumber,
            @RequestParam String qualifications,
            @RequestParam Integer yearsOfExperience,
            @RequestParam Double consultationFee,
            @RequestParam(required = false) String assignedCabin,
            @RequestParam(required = false) String availabilityTimings,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) {
            return "redirect:/login";
        }

        String doctorIdNumber = user.getUsername();

        if (profileService.createDoctorProfile(
                user, doctorIdNumber, department, medicalLicenseNumber, 
                qualifications, yearsOfExperience, consultationFee, 
                assignedCabin, availabilityTimings) != null) {
            
            redirectAttributes.addFlashAttribute("success", "Doctor profile setup successfully!");
            return "redirect:/dashboard"; 
        }

        redirectAttributes.addFlashAttribute("error", "Profile already exists or could not be created.");
        return "redirect:/doctor/setup"; 
    }

    // ============================================
    // VSOP Profile Endpoints
    // ============================================

    @GetMapping("/vsop/profile")
    public String viewVsopProfile(HttpSession session, Model model) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null || !user.getRole().replace(" ", "").equalsIgnoreCase("vsop")) {
            return "redirect:/login";
        }
        
        model.addAttribute("userDetails", user);
        model.addAttribute("hospitalDetails", hospitalDetailsService.getDetails());
        
        return "vsop/profile";
    }

    @PostMapping("/vsop/profile/password")
    public String updateVsopPassword(@RequestParam String newPassword,
                                     @RequestParam String confirmPassword,
                                     HttpSession session,
                                     RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null || !user.getRole().replace(" ", "").equalsIgnoreCase("vsop")) {
            return "redirect:/login";
        }

        if (!newPassword.equals(confirmPassword)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Passwords do not match. Please try again.");
            return "redirect:/vsop/profile";
        }

        try {
            // Use the existing updatePassword method from UserService
            boolean isUpdated = userService.updatePassword(user.getId(), newPassword);
            
            if (isUpdated) {
                // Keep the session object in sync
                user.setPassword(newPassword);
                redirectAttributes.addFlashAttribute("successMessage", "Account password updated successfully!");
            } else {
                redirectAttributes.addFlashAttribute("errorMessage", "Could not find user to update.");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "An error occurred while updating the password.");
        }

        return "redirect:/vsop/profile";
    }
}