package com.osacare.myapp.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.osacare.myapp.entity.Department;
import com.osacare.myapp.entity.HospitalDetails;
import com.osacare.myapp.entity.User;
import com.osacare.myapp.service.DepartmentService;
import com.osacare.myapp.service.HospitalDetailsService;
import com.osacare.myapp.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final UserService userService;
    private final HospitalDetailsService hospitalDetailsService;
    private final DepartmentService departmentService;

    public AdminController(UserService userService, HospitalDetailsService hospitalDetailsService, DepartmentService departmentService) {
        this.userService = userService;
        this.hospitalDetailsService = hospitalDetailsService;
        this.departmentService = departmentService;
    }

    private boolean isAdmin(HttpSession session) {
        User user = (User) session.getAttribute("loggedInUser");
        return user != null && "Admin".equalsIgnoreCase(user.getRole());
    }

    @GetMapping("/dashboard")
    public String adminDashboard(HttpSession session, Model model) {
        if (!isAdmin(session)) return "redirect:/login";

        User user = (User) session.getAttribute("loggedInUser");
        model.addAttribute("name", user.getName());
        model.addAttribute("username", user.getUsername());
        model.addAttribute("email", user.getEmail());
        model.addAttribute("role", user.getRole()); 
        return "admin/dashboard";
    }

    @GetMapping("/users")
    public String manageUsers(HttpSession session, Model model) {
        if (!isAdmin(session)) return "redirect:/login";
        model.addAttribute("users", userService.getAllUsers());
        return "admin/manage-users";
    }

    @GetMapping("/users/create")
    public String createUserForm(HttpSession session, Model model) {
        if (!isAdmin(session)) return "redirect:/login";
        
        // Fetch departments for the dynamic dropdown in doctor profile
        model.addAttribute("departments", departmentService.getAllDepartments());
        
        return "admin/create-user";
    }

    @PostMapping("/users/create")
    public String createUser(@RequestParam Map<String, String> allParams, HttpSession session, RedirectAttributes redirectAttributes) {
        if (!isAdmin(session)) return "redirect:/login";

        try {
            User newUser = userService.createUserByAdmin(allParams);
            if (newUser != null) {
                redirectAttributes.addFlashAttribute("success", "User created successfully! System ID / Default Password: <strong>" + newUser.getUsername() + "</strong>");
                return "redirect:/admin/users"; 
            } else {
                redirectAttributes.addFlashAttribute("error", "Failed to create user. Email might already be in use.");
                return "redirect:/admin/users/create"; 
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "An unexpected error occurred: " + e.getMessage());
            return "redirect:/admin/users/create"; 
        }
    }

    // AJAX Endpoint to dynamically add a new Specialization/Department
    @PostMapping("/departments/add")
    @ResponseBody
    public ResponseEntity<?> addDepartment(@RequestParam("name") String name, HttpSession session) {
        if (!isAdmin(session)) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized");
        try {
            Department dept = departmentService.addDepartment(name);
            return ResponseEntity.ok(dept);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to add department.");
        }
    }

    @GetMapping("/users/view")
    public String viewUser(@RequestParam Long id, HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        if (!isAdmin(session)) return "redirect:/login";
        User user = userService.getUserById(id);
        if (user == null) {
            redirectAttributes.addFlashAttribute("error", "User not found.");
            return "redirect:/admin/users";
        }
        model.addAttribute("user", user);
        return "admin/view-user";
    }

    @GetMapping("/users/edit")
    public String editUserForm(@RequestParam Long id, HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        if (!isAdmin(session)) return "redirect:/login";
        
        User user = userService.getUserById(id);
        if (user == null) {
            redirectAttributes.addFlashAttribute("error", "User not found.");
            return "redirect:/admin/users";
        }
        
        model.addAttribute("user", user);
        
        // Fetch departments for the dynamic dropdown in doctor profile editing
        model.addAttribute("departments", departmentService.getAllDepartments());
        
        return "admin/edit-user";
    }

    @PostMapping("/users/edit")
    public String editUserSubmit(@RequestParam Map<String, String> allParams, 
                                 HttpSession session, RedirectAttributes redirectAttributes) {
        if (!isAdmin(session)) return "redirect:/login";

        Long id = Long.parseLong(allParams.get("id"));
        boolean active = Boolean.parseBoolean(allParams.get("active"));

        User loggedInUser = (User) session.getAttribute("loggedInUser");
        if (loggedInUser.getId().equals(id) && !active) {
            redirectAttributes.addFlashAttribute("error", "You cannot deactivate your own admin account.");
            return "redirect:/admin/users/edit?id=" + id;
        }

        try {
            userService.updateUserByAdmin(id, allParams);
            redirectAttributes.addFlashAttribute("success", "User profile updated successfully.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to update profile. Email might already be in use.");
        }
        return "redirect:/admin/users/edit?id=" + id; 
    }

    @PostMapping("/users/toggle-status")
    public String toggleStatus(@RequestParam Long userId, HttpSession session, RedirectAttributes redirectAttributes) {
        if (!isAdmin(session)) return "redirect:/login";
        
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        if (loggedInUser.getId().equals(userId)) {
            redirectAttributes.addFlashAttribute("error", "You cannot deactivate your own admin account.");
            return "redirect:/admin/users";
        }

        boolean newState = userService.toggleUserStatus(userId);
        redirectAttributes.addFlashAttribute("success", "User account is now " + (newState ? "Active" : "Inactive") + ".");
        return "redirect:/admin/users";
    }

    @PostMapping("/users/reset-password")
    public String resetPassword(@RequestParam Long userId, @RequestParam String newPassword, 
                                @RequestParam String confirmPassword, @RequestParam(required = false) String returnUrl,
                                HttpSession session, RedirectAttributes redirectAttributes) {
        if (!isAdmin(session)) return "redirect:/login";

        if (!newPassword.equals(confirmPassword)) {
            redirectAttributes.addFlashAttribute("error", "Passwords do not match. Reset failed.");
        } else {
            userService.updatePassword(userId, newPassword);
            redirectAttributes.addFlashAttribute("success", "Password updated successfully.");
        }

        if (returnUrl != null && !returnUrl.isEmpty()) {
            return "redirect:" + returnUrl; 
        }
        return "redirect:/admin/users"; 
    }

    @PostMapping("/users/delete")
    public String deleteUser(@RequestParam Long userId, HttpSession session, RedirectAttributes redirectAttributes) {
        if (!isAdmin(session)) return "redirect:/login";
        
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        if (loggedInUser.getId().equals(userId)) {
            redirectAttributes.addFlashAttribute("error", "You cannot delete your own admin account.");
            return "redirect:/admin/users";
        }

        userService.deleteUser(userId);
        redirectAttributes.addFlashAttribute("success", "User account deleted successfully.");
        return "redirect:/admin/users"; 
    }

    @GetMapping("/settings")
    public String manageSettings(HttpSession session, Model model) {
        if (!isAdmin(session)) return "redirect:/login";
        model.addAttribute("hospitalDetails", hospitalDetailsService.getDetails());
        return "admin/settings";
    }

    @PostMapping("/settings")
    public String updateSettings(@ModelAttribute HospitalDetails hospitalDetails, 
                                 @RequestParam(value = "logoImage", required = false) MultipartFile logoImage,
                                 HttpSession session, RedirectAttributes redirectAttributes) {
        if (!isAdmin(session)) return "redirect:/login";

        try {
            if (logoImage != null && !logoImage.isEmpty()) {
                HospitalDetails existingDetails = hospitalDetailsService.getDetails();
                
                if (existingDetails.getLogoUrl() != null && !existingDetails.getLogoUrl().isEmpty()) {
                    String oldLogoLocalPath = "." + existingDetails.getLogoUrl();
                    Path oldFilePath = Paths.get(oldLogoLocalPath);
                    try {
                        Files.deleteIfExists(oldFilePath);
                    } catch (IOException e) {
                        System.err.println("Could not delete old logo file: " + e.getMessage());
                    }
                }

                String uploadDir = "./uploads/logos/";
                Path uploadPath = Paths.get(uploadDir);

                if (!Files.exists(uploadPath)) {
                    Files.createDirectories(uploadPath);
                }

                String originalFileName = StringUtils.cleanPath(logoImage.getOriginalFilename());
                String uniqueFileName = System.currentTimeMillis() + "_" + originalFileName;

                Path filePath = uploadPath.resolve(uniqueFileName);
                Files.copy(logoImage.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

                hospitalDetails.setLogoUrl("/uploads/logos/" + uniqueFileName);
            } else {
                HospitalDetails existingDetails = hospitalDetailsService.getDetails();
                hospitalDetails.setLogoUrl(existingDetails.getLogoUrl());
            }
        } catch (IOException e) {
            redirectAttributes.addFlashAttribute("error", "Failed to store the logo image.");
            return "redirect:/admin/settings";
        }

        hospitalDetailsService.saveDetails(hospitalDetails);
        redirectAttributes.addFlashAttribute("success", "Hospital details updated successfully.");
        return "redirect:/admin/settings"; 
    }
}