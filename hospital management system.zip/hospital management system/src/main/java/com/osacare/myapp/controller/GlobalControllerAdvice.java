package com.osacare.myapp.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.osacare.myapp.entity.HospitalDetails;
import com.osacare.myapp.service.HospitalDetailsService;

@ControllerAdvice
public class GlobalControllerAdvice {

    private final HospitalDetailsService hospitalDetailsService;

    public GlobalControllerAdvice(HospitalDetailsService hospitalDetailsService) {
        this.hospitalDetailsService = hospitalDetailsService;
    }

    // This makes 'hospitalDetails' available to ALL Thymeleaf templates automatically
    @ModelAttribute("hospitalDetails")
    public HospitalDetails getGlobalHospitalDetails() {
        return hospitalDetailsService.getDetails();
    }
}