package com.osacare.myapp.controller;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.osacare.myapp.entity.User;
import com.osacare.myapp.service.HospitalDetailsService;
import com.osacare.myapp.service.UserService;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller
public class UserController {

    private final UserService userService;
    private final HospitalDetailsService hospitalDetailsService;

    public UserController(UserService userService, HospitalDetailsService hospitalDetailsService) {
        this.userService = userService;
        this.hospitalDetailsService = hospitalDetailsService;
    }

    @GetMapping("/")
    public String root(Model model) {
        model.addAttribute("hospitalDetails", hospitalDetailsService.getDetails());
        return "index"; 
    }

    @GetMapping("/signup")
    public String signupForm(Model model) {
        model.addAttribute("hospitalDetails", hospitalDetailsService.getDetails());
        return "signup";
    }

    @PostMapping("/signup")
    public String signupSubmit(@RequestParam Map<String, String> allParams,
                               RedirectAttributes redirectAttributes) {
        
        String firstName = allParams.get("firstName");
        String lastName = allParams.get("lastName");
        String email = allParams.get("email");
        String role = allParams.get("role");
        String password = allParams.get("password");
        String confirmPassword = allParams.get("confirmPassword");

        if (password == null || !password.equals(confirmPassword)) {
            redirectAttributes.addFlashAttribute("error", "Passwords do not match!");
            return "redirect:/signup"; 
        }

        if (role == null || role.trim().isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "Please select an account type.");
            return "redirect:/signup"; 
        }

        allParams.put("firstName", (firstName != null) ? firstName.trim() : "");
        allParams.put("lastName", (lastName != null) ? lastName.trim() : "");
        allParams.put("email", (email != null) ? email.trim() : "");

        try {
            // Register using the allParams map to catch the dynamic fields seamlessly
            User user = userService.registerUser(allParams);
            
            if (user == null) {
                redirectAttributes.addFlashAttribute("error", "An account with this Email already exists.");
                return "redirect:/signup"; 
            }

            redirectAttributes.addFlashAttribute("success", "Registration successful! Your System ID is: " + user.getUsername());
            redirectAttributes.addFlashAttribute("generatedId", user.getUsername()); 
            return "redirect:/login"; 
            
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "An unexpected error occurred during registration. Please try again.");
            return "redirect:/signup"; 
        }
    }

    // UPDATED: Added @CookieValue to check for existing remembered username
    @GetMapping("/login")
    public String loginForm(@CookieValue(value = "rememberedUsername", defaultValue = "") String rememberedUsername, Model model) {
        model.addAttribute("hospitalDetails", hospitalDetailsService.getDetails());
        model.addAttribute("rememberedUsername", rememberedUsername);
        return "login";
    }

    // UPDATED: Added rememberMe param and HttpServletResponse to set cookies
    @PostMapping("/login")
    public String loginSubmit(@RequestParam String username, 
                              @RequestParam String password, 
                              @RequestParam(value = "remember-me", required = false) String rememberMe,
                              HttpServletRequest request, 
                              HttpServletResponse response,
                              RedirectAttributes redirectAttributes) {
                                  
        User user = userService.authenticate(username, password);
        
        if (user != null) {
            HttpSession oldSession = request.getSession(false);
            if (oldSession != null) oldSession.invalidate();
            
            HttpSession newSession = request.getSession(true);
            newSession.setAttribute("loggedInUser", user);
            
            // Handle "Remember Me" Cookie Logic
            if (rememberMe != null) {
                // Create cookie for 30 days
                Cookie cookie = new Cookie("rememberedUsername", username);
                cookie.setMaxAge(30 * 24 * 60 * 60); // 30 days in seconds
                cookie.setPath("/");
                response.addCookie(cookie);
            } else {
                // Clear the cookie if the user unchecked "Remember me"
                Cookie cookie = new Cookie("rememberedUsername", "");
                cookie.setMaxAge(0);
                cookie.setPath("/");
                response.addCookie(cookie);
            }
            
            return "redirect:/dashboard"; 
        }
        
        redirectAttributes.addFlashAttribute("error", "Invalid System ID or password. Or account is inactive.");
        return "redirect:/login"; 
    }

    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) {
            return "redirect:/login";
        }
        
        model.addAttribute("name", user.getName());
        model.addAttribute("username", user.getUsername());
        model.addAttribute("email", user.getEmail());
        model.addAttribute("role", user.getRole()); 
        model.addAttribute("hospitalDetails", hospitalDetailsService.getDetails());
        
        String formattedRole = user.getRole().toLowerCase().replace(" ", "");
        
        switch (formattedRole) {
            case "admin": return "redirect:/admin/dashboard";
            case "patient": return "patient/dashboard";
            case "doctor": return "doctor/dashboard";
            case "receptionist": return "receptionist/dashboard";
            case "diagnosticlab": return "lab/dashboard"; 
            case "pharmacy": return "pharmacy/dashboard";
            case "helpteam": return "helpteam/dashboard";
            case "insuranceteam": return "insurance/dashboard"; 
            case "vsop": return "redirect:/vsop/dashboard";
            default:
                session.invalidate();
                return "redirect:/login";
        }
    }

    @PostMapping("/logout")
    public String logout(HttpSession session, RedirectAttributes redirectAttributes) {
        session.invalidate();
        redirectAttributes.addFlashAttribute("success", "You have been successfully logged out.");
        return "redirect:/login"; 
    }
}