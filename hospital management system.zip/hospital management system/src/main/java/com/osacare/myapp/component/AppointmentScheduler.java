package com.osacare.myapp.component;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.osacare.myapp.entity.Appointment;
import com.osacare.myapp.repository.AppointmentRepository;

@Component
public class AppointmentScheduler {

    @Autowired
    private AppointmentRepository appointmentRepository;

    // Runs every day at 11:59 PM (23:59:00) in the Asia/Kolkata timezone
    @Scheduled(cron = "0 59 23 * * ?", zone = "Asia/Kolkata")
    public void autoCloseCompletedAppointments() {
        // Fetch appointments where consultation is done or in reception but not closed
        List<Appointment> completedAppointments = appointmentRepository.findByStatus("COMPLETED");
        List<Appointment> inReception = appointmentRepository.findByStatus("IN_RECEPTION");
        
        List<Appointment> toClose = new ArrayList<>();
        if (completedAppointments != null) toClose.addAll(completedAppointments);
        if (inReception != null) toClose.addAll(inReception);
        
        if (!toClose.isEmpty()) {
            for (Appointment appt : toClose) {
                appt.setStatus("CLOSED"); // Auto mark as dispensed/closed
            }
            appointmentRepository.saveAll(toClose);
            System.out.println("Auto-closed " + toClose.size() + " appointments at 11:59 PM.");
        }
    }
}