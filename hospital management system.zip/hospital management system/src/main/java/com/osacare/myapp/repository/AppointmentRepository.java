package com.osacare.myapp.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.osacare.myapp.entity.Appointment;
import com.osacare.myapp.entity.User;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
    
    // Used to count how many patients are already booked for a specific slot
    long countByDoctorAndAppointmentDateAndAppointmentTimeAndStatusNot(User doctor, LocalDate appointmentDate, String appointmentTime, String status);
    
    // Fetch all appointments for a given date with patient and doctor eagerly loaded
    @EntityGraph(attributePaths = {"patient", "doctor"})
    List<Appointment> findByAppointmentDate(LocalDate appointmentDate);

    // Fetch appointments by date and payment status for the VSOP queue
    @EntityGraph(attributePaths = {"patient", "doctor"})
    List<Appointment> findByAppointmentDateAndPaymentStatus(LocalDate appointmentDate, String paymentStatus);

    // Fetch appointments by date where token is generated, ordered serially by generation time
    @EntityGraph(attributePaths = {"patient", "doctor"})
    List<Appointment> findByAppointmentDateAndTokenIdIsNotNullOrderByTokenGeneratedAtAsc(LocalDate appointmentDate);

    // Fetch appointments for a specific doctor on a specific date, ordered by time
    @EntityGraph(attributePaths = {"patient"})
    List<Appointment> findByDoctorAndAppointmentDateOrderByAppointmentTimeAsc(User doctor, LocalDate appointmentDate);

    // Fetch all previous consultations for a specific patient, ordered by date
    @EntityGraph(attributePaths = {"doctor"})
    List<Appointment> findByPatientOrderByAppointmentDateDesc(User patient);

    // Fetch by token ID and patient username for QR Scanning/Print Prescription
    @EntityGraph(attributePaths = {"patient", "doctor"})
    List<Appointment> findByTokenIdAndPatientUsername(String tokenId, String username);

    // NEW: Fetch appointments by their current status for the scheduled auto-closer
    List<Appointment> findByStatus(String status);
}