package com.osacare.myapp.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.osacare.myapp.entity.DoctorProfile;
import com.osacare.myapp.entity.PatientProfile;
import com.osacare.myapp.entity.User;
import com.osacare.myapp.repository.DoctorProfileRepository;
import com.osacare.myapp.repository.PatientProfileRepository;

@Service
@Transactional
public class ProfileService {

    private final PatientProfileRepository patientProfileRepository;
    private final DoctorProfileRepository doctorProfileRepository;

    public ProfileService(PatientProfileRepository patientProfileRepository, DoctorProfileRepository doctorProfileRepository) {
        this.patientProfileRepository = patientProfileRepository;
        this.doctorProfileRepository = doctorProfileRepository;
    }

    public PatientProfile createPatientProfile(
            User user, String patientIdNumber, Integer birthYear, String gender, String bloodGroup, 
            String address, String nationalIdName, String nationalIdNumber,
            String emergencyContactName, String emergencyContactNumber, String emergencyContactAddress,
            String chiefComplaint, String illnessHistory, String surgicalHistory, String allergies, String familyHistory) {
        
        if (patientProfileRepository.findByUser(user) != null) {
            return null; // Profile already exists for this user
        }

        PatientProfile profile = new PatientProfile();
        profile.setUser(user);
        profile.setPatientIdNumber(patientIdNumber);
        profile.setBirthYear(birthYear);
        profile.setGender(gender);
        profile.setBloodGroup(bloodGroup);
        profile.setAddress(address);
        
        profile.setNationalIdName(nationalIdName);
        profile.setNationalIdNumber(nationalIdNumber);
        
        profile.setEmergencyContactName(emergencyContactName);
        profile.setEmergencyContactNumber(emergencyContactNumber);
        profile.setEmergencyContactAddress(emergencyContactAddress);
        
        profile.setChiefComplaint(chiefComplaint);
        profile.setIllnessHistory(illnessHistory);
        profile.setSurgicalHistory(surgicalHistory);
        profile.setAllergies(allergies);
        profile.setFamilyHistory(familyHistory);

        return patientProfileRepository.save(profile);
    }

    public DoctorProfile createDoctorProfile(
            User user, String doctorIdNumber, String department, String medicalLicenseNumber, 
            String qualifications, Integer yearsOfExperience, Double consultationFee, 
            String assignedCabin, String availabilityTimings) {
            
        if (doctorProfileRepository.findByUser(user) != null) {
            return null; // Profile already exists for this user
        }

        DoctorProfile profile = new DoctorProfile();
        profile.setUser(user);
        profile.setDoctorIdNumber(doctorIdNumber);
        profile.setDepartment(department);
        profile.setMedicalLicenseNumber(medicalLicenseNumber);
        profile.setQualifications(qualifications);
        profile.setYearsOfExperience(yearsOfExperience);
        profile.setConsultationFee(consultationFee);
        profile.setAssignedCabin(assignedCabin);
        profile.setAvailabilityTimings(availabilityTimings);

        return doctorProfileRepository.save(profile);
    }
}