package com.osacare.myapp.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

@Entity
@Table(name = "appointments")
public class Appointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "patient_id", nullable = false)
    private User patient;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "doctor_id", nullable = false)
    private User doctor;

    private String department;

    @Column(name = "appointment_date", nullable = false)
    private LocalDate appointmentDate;

    @Column(name = "appointment_time", nullable = false)
    private String appointmentTime;

    @Column(columnDefinition = "TEXT")
    private String reason;

    // Relational mapping replacing the primitive strings
    @OneToOne(mappedBy = "appointment", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private Prescription prescriptionRecord;

    @Column(nullable = false)
    private String status = "SCHEDULED";
    
    @Column(name = "payment_status", nullable = false)
    private String paymentStatus = "PENDING";

    @Column(name = "token_id")
    private String tokenId;

    @Column(name = "token_generated_at")
    private LocalDateTime tokenGeneratedAt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "booked_by_id", nullable = true)
    private User bookedBy;

    @Column(name = "is_urgent", columnDefinition = "boolean default false")
    private Boolean isUrgent = false;

    @Column(name = "created_at", updatable = false)
    private ZonedDateTime createdAt;

    public Appointment() {}

    @PrePersist
    protected void onCreate() {
        this.createdAt = ZonedDateTime.now(ZoneId.of("Asia/Kolkata"));
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public User getPatient() { return patient; }
    public void setPatient(User patient) { this.patient = patient; }

    public User getDoctor() { return doctor; }
    public void setDoctor(User doctor) { this.doctor = doctor; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public LocalDate getAppointmentDate() { return appointmentDate; }
    public void setAppointmentDate(LocalDate appointmentDate) { this.appointmentDate = appointmentDate; }

    public String getAppointmentTime() { return appointmentTime; }
    public void setAppointmentTime(String appointmentTime) { this.appointmentTime = appointmentTime; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public Prescription getPrescriptionRecord() { return prescriptionRecord; }
    public void setPrescriptionRecord(Prescription prescriptionRecord) { this.prescriptionRecord = prescriptionRecord; }

    // Helper methods to retrieve string text natively. Leaves thymeleaf templates unbroken.
    public String getChiefComplaints() { 
        return prescriptionRecord != null ? prescriptionRecord.getChiefComplaints() : null; 
    }
    public void setChiefComplaints(String chiefComplaints) { 
        if (this.prescriptionRecord != null) {
            this.prescriptionRecord.setChiefComplaints(chiefComplaints);
        }
    }

    public String getPrescription() { 
        return prescriptionRecord != null ? prescriptionRecord.getPrescriptionText() : null; 
    }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getPaymentStatus() { return paymentStatus; }
    public void setPaymentStatus(String paymentStatus) { this.paymentStatus = paymentStatus; }

    public String getTokenId() { return tokenId; }
    public void setTokenId(String tokenId) { this.tokenId = tokenId; }

    public LocalDateTime getTokenGeneratedAt() { return tokenGeneratedAt; }
    public void setTokenGeneratedAt(LocalDateTime tokenGeneratedAt) { this.tokenGeneratedAt = tokenGeneratedAt; }

    public User getBookedBy() { return bookedBy; }
    public void setBookedBy(User bookedBy) { this.bookedBy = bookedBy; }

    public Boolean isUrgent() { return isUrgent != null ? isUrgent : false; }
    public void setUrgent(Boolean isUrgent) { this.isUrgent = isUrgent; }

    public ZonedDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(ZonedDateTime createdAt) { this.createdAt = createdAt; }
}