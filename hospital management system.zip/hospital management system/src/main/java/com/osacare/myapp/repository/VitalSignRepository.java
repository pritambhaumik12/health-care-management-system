package com.osacare.myapp.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.osacare.myapp.entity.User;
import com.osacare.myapp.entity.VitalSign;

@Repository
public interface VitalSignRepository extends JpaRepository<VitalSign, Long> {
    
    VitalSign findByAppointmentId(Long appointmentId);

    // Fetch vitals recorded by a specific user within a date/time range
    List<VitalSign> findByRecordedByAndRecordedAtBetweenOrderByRecordedAtDesc(User recordedBy, LocalDateTime start, LocalDateTime end);
}