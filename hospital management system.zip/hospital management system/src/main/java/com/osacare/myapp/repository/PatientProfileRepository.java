package com.osacare.myapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.osacare.myapp.entity.PatientProfile;
import com.osacare.myapp.entity.User;

public interface PatientProfileRepository extends JpaRepository<PatientProfile, Long> {
    PatientProfile findByUser(User user);
    PatientProfile findByPatientIdNumber(String patientIdNumber);
}