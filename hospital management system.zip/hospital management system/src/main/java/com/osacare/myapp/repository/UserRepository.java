package com.osacare.myapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.osacare.myapp.entity.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    
    User findByUsername(String username);
    
    User findByEmail(String email);
    
    List<User> findAllByOrderByIdDesc();
    
    // Retrieves the most recently created user for a specific role
    User findFirstByRoleOrderByIdDesc(String role);

    // Search for Patient auto-suggest drop down including mobile number
    @Query("SELECT u FROM User u WHERE u.role = 'Patient' AND " +
           "(LOWER(u.username) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(u.firstName) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(u.lastName) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "u.phoneNumber LIKE CONCAT('%', :query, '%'))")
    List<User> searchPatients(@Param("query") String query);
}