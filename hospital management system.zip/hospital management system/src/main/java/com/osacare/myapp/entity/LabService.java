package com.osacare.myapp.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "lab_services")
public class LabService {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String serviceName;
    
    @Column(columnDefinition = "TEXT")
    private String description;
    
    private Double price;
    
    @Column(length = 1000)
    private String availabilityTimings;
    
    private String resultDuration;
    
    @Column(columnDefinition = "TEXT")
    private String testingRules;
    
    // NEW FIELD FOR REPORT CONFIGURATION
    @Column(columnDefinition = "TEXT")
    private String reportTemplateConfig;
    
    private boolean active = true;

    // Existing Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getServiceName() { return serviceName; }
    public void setServiceName(String serviceName) { this.serviceName = serviceName; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public Double getPrice() { return price; }
    public void setPrice(Double price) { this.price = price; }

    public String getAvailabilityTimings() { return availabilityTimings; }
    public void setAvailabilityTimings(String availabilityTimings) { this.availabilityTimings = availabilityTimings; }

    public String getResultDuration() { return resultDuration; }
    public void setResultDuration(String resultDuration) { this.resultDuration = resultDuration; }

    public String getTestingRules() { return testingRules; }
    public void setTestingRules(String testingRules) { this.testingRules = testingRules; }

    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }

    // New Getters & Setters
    public String getReportTemplateConfig() { return reportTemplateConfig; }
    public void setReportTemplateConfig(String reportTemplateConfig) { this.reportTemplateConfig = reportTemplateConfig; }
}