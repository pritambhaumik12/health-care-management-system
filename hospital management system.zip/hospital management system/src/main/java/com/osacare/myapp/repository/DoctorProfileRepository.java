package com.osacare.myapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.osacare.myapp.entity.DoctorProfile;
import com.osacare.myapp.entity.User;

public interface DoctorProfileRepository extends JpaRepository<DoctorProfile, Long> {
    DoctorProfile findByUser(User user);
    List<DoctorProfile> findByDepartment(String department);
}