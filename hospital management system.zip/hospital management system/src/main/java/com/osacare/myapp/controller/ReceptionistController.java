package com.osacare.myapp.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.osacare.myapp.entity.Appointment;
import com.osacare.myapp.entity.AppointmentPayment;
import com.osacare.myapp.entity.Department;
import com.osacare.myapp.entity.DoctorProfile;
import com.osacare.myapp.entity.HospitalDetails;
import com.osacare.myapp.entity.LabPayment;
import com.osacare.myapp.entity.LabService;
import com.osacare.myapp.entity.User;
import com.osacare.myapp.entity.VitalSign;
import com.osacare.myapp.repository.AppointmentPaymentRepository;
import com.osacare.myapp.repository.AppointmentRepository;
import com.osacare.myapp.repository.DoctorProfileRepository;
import com.osacare.myapp.repository.HospitalDetailsRepository;
import com.osacare.myapp.repository.LabPaymentRepository;
import com.osacare.myapp.repository.LabServiceRepository;
import com.osacare.myapp.repository.UserRepository;
import com.osacare.myapp.repository.VitalSignRepository;
import com.osacare.myapp.service.DepartmentService;
import com.osacare.myapp.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/receptionist")
public class ReceptionistController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private DepartmentService departmentService;

    @Autowired
    private DoctorProfileRepository doctorProfileRepository;

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Autowired
    private AppointmentPaymentRepository appointmentPaymentRepository;

    @Autowired
    private LabPaymentRepository labPaymentRepository;

    @Autowired
    private LabServiceRepository labServiceRepository;

    @Autowired
    private VitalSignRepository vitalSignRepository;
    
    @Autowired
    private HospitalDetailsRepository hospitalDetailsRepository;

    private String generateTokenId() {
        String letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String numbers = "0123456789";
        Random rnd = new Random();
        return "" + letters.charAt(rnd.nextInt(letters.length()))
                  + numbers.charAt(rnd.nextInt(numbers.length()))
                  + letters.charAt(rnd.nextInt(letters.length()))
                  + numbers.charAt(rnd.nextInt(numbers.length()));
    }

    @GetMapping("/dashboard")
    public String showDashboard(Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);
        return "receptionist/dashboard";
    }

    // ---------- NEW PATIENT DETAILS ENDPOINT ---------- //
    @GetMapping("/patient-details")
    public String showPatientDetails(@RequestParam(required = false) String patientId, Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);

        if (patientId != null && !patientId.trim().isEmpty()) {
            User patient = userRepository.findByUsername(patientId.trim());
            if (patient != null && "Patient".equalsIgnoreCase(patient.getRole())) {
                model.addAttribute("patient", patient);
                
                // Fetch only CLOSED (dispensed) appointments/prescriptions for this patient
                List<Appointment> dispensedAppointments = appointmentRepository.findByPatientOrderByAppointmentDateDesc(patient)
                    .stream()
                    .filter(a -> "CLOSED".equalsIgnoreCase(a.getStatus()))
                    .collect(Collectors.toList());
                
                model.addAttribute("appointments", dispensedAppointments);
            } else {
                model.addAttribute("errorMessage", "Patient not found or invalid ID.");
            }
        }
        return "receptionist/patient-details";
    }

    // ---------- PRESCRIPTION ENDPOINTS ---------- //

    @GetMapping("/print-prescription")
    public String showPrintPrescription(Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);
        return "receptionist/print-prescription";
    }

    @GetMapping("/prescription-results")
    public String searchPrescriptions(@RequestParam(required = false) String tokenId,
                                      @RequestParam(required = false) String patientId,
                                      Model model, HttpSession session, RedirectAttributes redirectAttributes) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);

        if ((tokenId == null || tokenId.trim().isEmpty()) && (patientId == null || patientId.trim().isEmpty())) {
            redirectAttributes.addFlashAttribute("errorMessage", "Please enter either a Token Number or a Patient details to search.");
            return "redirect:/receptionist/print-prescription";
        }

        try {
            List<Appointment> results = new ArrayList<>();
            
            // PRIORITY: If Token ID is present, fetch that specific prescription
            if (tokenId != null && !tokenId.trim().isEmpty()) {
                List<Appointment> byToken = appointmentRepository.findAll().stream()
                    .filter(a -> tokenId.equalsIgnoreCase(a.getTokenId()))
                    .collect(Collectors.toList());
                
                // If multiple prescriptions share the same token, filter down by patientId (if provided)
                if (byToken.size() > 1 && patientId != null && !patientId.trim().isEmpty()) {
                    byToken = byToken.stream()
                        .filter(a -> a.getPatient() != null && patientId.trim().equalsIgnoreCase(a.getPatient().getUsername()))
                        .collect(Collectors.toList());
                }
                
                results.addAll(byToken);
            } 
            // FALLBACK: If NO Token ID, search by Patient ID dynamically
            else if (patientId != null && !patientId.trim().isEmpty()) {
                User patient = userRepository.findByUsername(patientId.trim());
                if (patient != null) {
                    List<Appointment> byPatient = appointmentRepository.findByPatientOrderByAppointmentDateDesc(patient);
                    results.addAll(byPatient);
                }
            }

            // Filter ONLY for Consultation done (COMPLETED) or in reception (IN_RECEPTION)
            List<Appointment> filteredResults = results.stream()
                .filter(a -> "COMPLETED".equalsIgnoreCase(a.getStatus()) || "IN_RECEPTION".equalsIgnoreCase(a.getStatus()))
                .collect(Collectors.toList());

            if (filteredResults.isEmpty()) {
                redirectAttributes.addFlashAttribute("errorMessage", "No ready prescriptions found for the provided details. The consultation might be pending or already dispensed.");
                return "redirect:/receptionist/print-prescription";
            }

            model.addAttribute("appointments", filteredResults);
            return "receptionist/prescription-results";

        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error searching prescriptions: " + e.getMessage());
            return "redirect:/receptionist/print-prescription";
        }
    }

    @PostMapping("/prescription/complete")
    public String completePrescription(@RequestParam Long appointmentId, RedirectAttributes redirectAttributes) {
        try {
            Appointment appt = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment not found."));
            
            appt.setStatus("CLOSED"); // Mark as dispensed/completed
            appointmentRepository.save(appt);
            
            redirectAttributes.addFlashAttribute("successMessage", "Prescription marked as successfully dispensed.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error: " + e.getMessage());
        }
        // Redirect PRG Pattern
        return "redirect:/receptionist/print-prescription";
    }

    @GetMapping("/prescription/download/{id}")
    public String downloadPrescription(@PathVariable Long id, Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        
        Appointment appointment = appointmentRepository.findById(id).orElse(null);
        if (appointment == null) return "redirect:/receptionist/print-prescription";

        model.addAttribute("appointment", appointment);

        VitalSign vitals = vitalSignRepository.findByAppointmentId(id);
        model.addAttribute("vitals", vitals);

        List<HospitalDetails> hdList = hospitalDetailsRepository.findAll();
        if (!hdList.isEmpty()) {
            model.addAttribute("hospitalDetails", hdList.get(0));
        }

        if (appointment.getPatient() != null && appointment.getPatient().getPatientProfile() != null && appointment.getPatient().getPatientProfile().getDateOfBirth() != null) {
            int age = java.time.Period.between(appointment.getPatient().getPatientProfile().getDateOfBirth(), java.time.LocalDate.now()).getYears();
            model.addAttribute("patientAge", age);
        }

        return "receptionist/prescription-print-view";
    }
    // ------------------------------------------------ //

    @GetMapping("/id-cards")
    public String showIdCards(@RequestParam(required = false) String patientId, Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);

        if (patientId != null && !patientId.trim().isEmpty()) {
            User patient = userRepository.findByUsername(patientId.trim());
            if (patient != null && "Patient".equalsIgnoreCase(patient.getRole())) {
                model.addAttribute("patient", patient);
            } else {
                model.addAttribute("errorMessage", "No patient found with ID: " + patientId);
            }
        }
        return "receptionist/id-cards";
    }

    @GetMapping("/profile")
    public String showProfile(Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);
        
        User sessionUser = (User) session.getAttribute("loggedInUser");
        User freshUser = userRepository.findById(sessionUser.getId()).orElse(null);
        if (freshUser == null) return "redirect:/login";

        model.addAttribute("userDetails", freshUser);
        return "receptionist/profile";
    }

    @PostMapping("/profile/tpin")
    public String updateTPin(
            @RequestParam String tpin, 
            @RequestParam String confirmTpin, 
            HttpSession session, 
            RedirectAttributes redirectAttributes) {
        
        if (!isLoggedIn(session)) return "redirect:/login";
        
        if (!tpin.equals(confirmTpin)) {
            redirectAttributes.addFlashAttribute("errorMessage", "T-Pins do not match!");
            return "redirect:/receptionist/profile";
        }

        try {
            User sessionUser = (User) session.getAttribute("loggedInUser");
            User user = userRepository.findById(sessionUser.getId())
                .orElseThrow(() -> new RuntimeException("User not found"));
            
            user.settPin(tpin);
            userRepository.save(user);
            redirectAttributes.addFlashAttribute("successMessage", "T-Pin updated successfully.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error updating T-Pin: " + e.getMessage());
        }

        return "redirect:/receptionist/profile"; 
    }

    @PostMapping("/profile/password")
    public String updatePassword(
            @RequestParam String newPassword, 
            @RequestParam String confirmPassword, 
            HttpSession session, 
            RedirectAttributes redirectAttributes) {
        
        if (!isLoggedIn(session)) return "redirect:/login";
        
        if (!newPassword.equals(confirmPassword)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Passwords do not match!");
            return "redirect:/receptionist/profile";
        }

        try {
            User sessionUser = (User) session.getAttribute("loggedInUser");
            User user = userRepository.findById(sessionUser.getId())
                .orElseThrow(() -> new RuntimeException("User not found"));
            
            user.setPassword(newPassword);
            userRepository.save(user);
            session.setAttribute("loggedInUser", user); 
            redirectAttributes.addFlashAttribute("successMessage", "Password updated successfully.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error updating Password: " + e.getMessage());
        }

        return "redirect:/receptionist/profile"; 
    }

    @GetMapping("/register")
    public String showRegistrationForm(Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);
        return "receptionist/register";
    }

    @PostMapping("/register")
    public String registerNewPatient(
            @RequestParam Map<String, String> allParams,
            RedirectAttributes redirectAttributes) {

        try {
            String name = allParams.get("name");
            if (name != null && !name.trim().isEmpty()) {
                String[] parts = name.trim().split("\\s+", 2);
                allParams.put("firstName", parts[0]);
                allParams.put("lastName", parts.length > 1 ? parts[1] : "");
            }
            
            allParams.put("role", "Patient");
            allParams.put("phoneNumber", allParams.get("phone"));
            allParams.put("patientGender", allParams.get("gender"));
            allParams.put("patientBloodGroup", allParams.get("bloodGroup"));
            allParams.put("patientAddress", allParams.get("address"));
            allParams.put("emergencyContactNumber", allParams.get("emergencyDetails"));
            
            String abhaId = allParams.get("abhaId");
            if (abhaId != null && !abhaId.isEmpty()) {
                allParams.put("nationalIdName", "ABHA");
                allParams.put("nationalIdNumber", abhaId);
            } else {
                allParams.put("nationalIdName", "National ID");
                allParams.put("nationalIdNumber", allParams.get("nationalId"));
            }
            
            String dob = allParams.get("dob");
            if (dob != null && !dob.isEmpty()) {
                allParams.put("password", dob.replace("-", ""));
                allParams.put("dateOfBirth", dob);
            } else {
                allParams.put("password", "password123");
            }

            User patientUser = userService.registerUser(allParams);

            if (patientUser == null) {
                redirectAttributes.addFlashAttribute("errorMessage", "Error registering patient: An account with this Email already exists.");
            } else {
                redirectAttributes.addFlashAttribute("successMessage", 
                    "Patient registered successfully! System Generated Patient ID: " + patientUser.getUsername());
            }

        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error registering patient: " + e.getMessage());
        }

        return "redirect:/receptionist/register";
    }

    @GetMapping("/appointments")
    public String showAppointments(@RequestParam(required = false) String date, Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);
        
        ZoneId istZone = ZoneId.of("Asia/Kolkata");
        LocalDate targetDate;
        
        if (date != null && !date.trim().isEmpty()) {
            try {
                targetDate = LocalDate.parse(date);
            } catch (Exception e) {
                targetDate = LocalDate.now(istZone);
            }
        } else {
            targetDate = LocalDate.now(istZone);
        }
        
        List<Appointment> targetAppointments = appointmentRepository.findByAppointmentDate(targetDate);
        
        model.addAttribute("appointments", targetAppointments);
        model.addAttribute("selectedDate", targetDate.toString());
        
        return "receptionist/appointments";
    }

    @GetMapping("/appointments/view/{id}")
    public String viewAppointmentDetails(@PathVariable Long id, Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);
        
        Appointment appointment = appointmentRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Appointment not found"));
            
        model.addAttribute("appointment", appointment);
        model.addAttribute("departments", departmentService.getAllDepartments());
        
        return "receptionist/appointment-details";
    }

    @PostMapping("/appointments/update")
    public String updateAppointment(@RequestParam Long id, 
                                    @RequestParam String appointmentDate,
                                    @RequestParam String appointmentTime,
                                    @RequestParam String status,
                                    @RequestParam(required = false) String department,
                                    @RequestParam(required = false) Long doctorId,
                                    RedirectAttributes redirectAttributes) {
        try {
            Appointment appointment = appointmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Appointment not found"));
            
            if (department != null && !department.isEmpty()) {
                appointment.setDepartment(department);
            }
            if (doctorId != null) {
                DoctorProfile doctorProfile = doctorProfileRepository.findById(doctorId)
                    .orElseThrow(() -> new RuntimeException("Doctor not found"));
                appointment.setDoctor(doctorProfile.getUser());
            }

            appointment.setAppointmentDate(LocalDate.parse(appointmentDate));
            appointment.setAppointmentTime(appointmentTime);
            appointment.setStatus(status.toUpperCase());
            
            appointmentRepository.save(appointment);
            redirectAttributes.addFlashAttribute("successMessage", "Appointment updated successfully.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to update: " + e.getMessage());
        }
        return "redirect:/receptionist/appointments/view/" + id;
    }

    @PostMapping("/appointments/cancel")
    public String cancelAppointment(@RequestParam Long id, RedirectAttributes redirectAttributes) {
        try {
            Appointment appointment = appointmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Appointment not found"));
                
            appointment.setStatus("CANCELLED");
            appointmentRepository.save(appointment);
            
            redirectAttributes.addFlashAttribute("successMessage", "Appointment has been cancelled.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to cancel: " + e.getMessage());
        }
        return "redirect:/receptionist/appointments/view/" + id;
    }

    @GetMapping("/appointments/new")
    public String showNewAppointmentForm(Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);
        
        List<Department> departments = departmentService.getAllDepartments();
        model.addAttribute("departments", departments);

        return "receptionist/new-appointment"; 
    }

    @PostMapping("/appointments/new")
    public String bookNewAppointment(@RequestParam Map<String, String> params, RedirectAttributes redirectAttributes, HttpSession session) {
        try {
            User loggedInUser = (User) session.getAttribute("loggedInUser");
            if (loggedInUser == null) return "redirect:/login";

            String patientId = params.get("patientId");
            String doctorIdStr = params.get("doctorId");
            String appointmentDateStr = params.get("appointmentDate");
            String appointmentTime = params.get("appointmentTime");
            String reason = params.get("reason");
            String department = params.get("department");

            User patient = userRepository.findByUsername(patientId);
            if (patient == null) {
                throw new RuntimeException("Invalid Patient ID.");
            }

            DoctorProfile doctorProfile = doctorProfileRepository.findById(Long.parseLong(doctorIdStr))
                .orElseThrow(() -> new RuntimeException("Doctor not found."));

            Map<String, Object> draftAppt = new HashMap<>();
            draftAppt.put("doctorId", doctorProfile.getId());
            draftAppt.put("department", department);
            draftAppt.put("appointmentDate", appointmentDateStr);
            draftAppt.put("appointmentTime", appointmentTime);
            draftAppt.put("reason", reason);
            
            Double fee = doctorProfile.getConsultationFee() != null ? doctorProfile.getConsultationFee() : 500.0;
            draftAppt.put("fee", fee);

            Map<String, Object> billingContext = new HashMap<>();
            billingContext.put("patientId", patient.getUsername());
            billingContext.put("patientName", patient.getName());
            billingContext.put("draftAppointment", draftAppt);
            
            session.setAttribute("billingContext", billingContext);
            
            redirectAttributes.addFlashAttribute("successMessage", 
                "Appointment drafted for Dr. " + doctorProfile.getUser().getName() + 
                ". Please complete the payment to finalize booking.");

            return "redirect:/receptionist/billing/payment";

        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to draft appointment: " + e.getMessage());
            return "redirect:/receptionist/appointments/new";
        }
    }

    @GetMapping("/billing")
    public String showBillingSearch(Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);
        session.removeAttribute("billingContext"); 
        return "receptionist/billing-search";
    }
    
    @GetMapping("/billing/invoices")
    public String viewAllInvoices(
            @RequestParam(required = false) String invoiceNumber,
            @RequestParam(required = false) String patientId,
            @RequestParam(required = false) String patientNameDisplay,
            @RequestParam(required = false) String searchType, 
            @RequestParam(required = false) String singleDate,
            @RequestParam(required = false) String startDate,
            @RequestParam(required = false) String endDate,
            Model model, HttpSession session) {
        
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);
        
        List<AppointmentPayment> invoices = appointmentPaymentRepository.findAllByOrderByTransactionDateDesc();
        
        if (invoiceNumber != null && !invoiceNumber.trim().isEmpty()) {
            invoices = invoices.stream()
                .filter(inv -> inv.getInvoiceNumber() != null && 
                               inv.getInvoiceNumber().toLowerCase().contains(invoiceNumber.trim().toLowerCase()))
                .collect(Collectors.toList());
            model.addAttribute("invoiceNumber", invoiceNumber.trim());
        }

        if (patientId != null && !patientId.trim().isEmpty()) {
            invoices = invoices.stream()
                .filter(inv -> inv.getPatient() != null && patientId.equals(inv.getPatient().getUsername()))
                .collect(Collectors.toList());
            model.addAttribute("selectedPatientId", patientId);
            model.addAttribute("patientNameDisplay", patientNameDisplay);
        }

        if ("DATE".equals(searchType) && singleDate != null && !singleDate.isEmpty()) {
            LocalDate date = LocalDate.parse(singleDate);
            invoices = invoices.stream()
                .filter(inv -> inv.getTransactionDate() != null && inv.getTransactionDate().toLocalDate().isEqual(date))
                .collect(Collectors.toList());
            model.addAttribute("singleDate", singleDate);
        } else if ("RANGE".equals(searchType) && startDate != null && !startDate.isEmpty() && endDate != null && !endDate.isEmpty()) {
            LocalDate start = LocalDate.parse(startDate);
            LocalDate end = LocalDate.parse(endDate);
            invoices = invoices.stream()
                .filter(inv -> inv.getTransactionDate() != null && 
                               !inv.getTransactionDate().toLocalDate().isBefore(start) && 
                               !inv.getTransactionDate().toLocalDate().isAfter(end))
                .collect(Collectors.toList());
            model.addAttribute("startDate", startDate);
            model.addAttribute("endDate", endDate);
        }

        model.addAttribute("searchType", searchType != null ? searchType : "ALL");
        model.addAttribute("invoices", invoices);
        
        return "receptionist/billing-invoices";
    }

    @PostMapping("/billing/step1")
    public String processSearch(@RequestParam String patientId, HttpSession session, RedirectAttributes redirectAttributes) {
        User patient = userRepository.findByUsername(patientId);
        if (patient == null || !"Patient".equalsIgnoreCase(patient.getRole())) {
            redirectAttributes.addFlashAttribute("errorMessage", "Invalid Patient ID.");
            return "redirect:/receptionist/billing";
        }
        
        Map<String, Object> billingContext = new HashMap<>();
        billingContext.put("patientId", patient.getUsername());
        billingContext.put("patientName", patient.getName());
        session.setAttribute("billingContext", billingContext);
        
        return "redirect:/receptionist/billing/select";
    }

    @GetMapping("/billing/select")
    public String showBillingSelect(Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);
        
        @SuppressWarnings("unchecked")
        Map<String, Object> billingContext = (Map<String, Object>) session.getAttribute("billingContext");
        if (billingContext == null) return "redirect:/receptionist/billing";
        
        String patientId = (String) billingContext.get("patientId");
        model.addAttribute("patientId", patientId);
        model.addAttribute("patientName", billingContext.get("patientName"));

        // Load Pending Appointments 
        List<Appointment> pendingAppointments = appointmentRepository.findAll().stream()
            .filter(a -> a.getPatient() != null 
                      && a.getPatient().getUsername() != null 
                      && a.getPatient().getUsername().equals(patientId) 
                      && "PENDING".equalsIgnoreCase(a.getPaymentStatus())
                      && !"CANCELLED".equalsIgnoreCase(a.getStatus()))
            .collect(Collectors.toList());
            
        model.addAttribute("pendingAppointments", pendingAppointments);

        Map<Long, Double> appointmentFees = new HashMap<>();
        for (Appointment a : pendingAppointments) {
            Double fee = 500.00; 
            if ("Free Follow up".equalsIgnoreCase(a.getReason())) {
                fee = 0.0;
            } else if (a.getDoctor() != null) {
                DoctorProfile profile = doctorProfileRepository.findByUser(a.getDoctor());
                if (profile != null && profile.getConsultationFee() != null) {
                    fee = profile.getConsultationFee();
                }
            }
            appointmentFees.put(a.getId(), fee);
        }
        model.addAttribute("appointmentFees", appointmentFees);

        // Fetch Lab Tests from Prescriptions dynamically
        List<Map<String, Object>> pendingLabTests = new ArrayList<>();
        List<LabService> labServices = labServiceRepository.findAll();
        List<LabPayment> existingPayments = labPaymentRepository.findAll().stream()
            .filter(lp -> lp.getPatient() != null && patientId.equals(lp.getPatient().getUsername()))
            .collect(Collectors.toList());

        List<Appointment> patientAppointments = appointmentRepository.findAll().stream()
            .filter(a -> a.getPatient() != null && patientId.equals(a.getPatient().getUsername()))
            .collect(Collectors.toList());

        for (Appointment appt : patientAppointments) {
            if (appt.getPrescription() != null) {
                java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\[Lab Test Prescribed: (.*?)\\]").matcher(appt.getPrescription());
                while (m.find()) {
                    String testName = m.group(1).trim();
                    String refId = appt.getId() + "_" + testName;
                    
                    boolean alreadyPaid = existingPayments.stream().anyMatch(lp -> refId.equals(lp.getLabReferenceId()));
                    if (!alreadyPaid) {
                        double cost = 850.0; // Default generic fallback
                        for (LabService ls : labServices) {
                            if (ls.getServiceName().equalsIgnoreCase(testName) && ls.getPrice() != null) {
                                cost = ls.getPrice();
                                break;
                            }
                        }
                        
                        Map<String, Object> labInfo = new HashMap<>();
                        labInfo.put("id", refId); 
                        labInfo.put("name", testName);
                        labInfo.put("date", appt.getAppointmentDate() != null ? appt.getAppointmentDate().toString() : "N/A");
                        labInfo.put("cost", cost);
                        
                        // Pass along Dr and Dept details
                        labInfo.put("doctorName", appt.getDoctor() != null ? appt.getDoctor().getName() : "Unknown");
                        labInfo.put("department", appt.getDepartment() != null ? appt.getDepartment() : "General");
                        
                        // Prevent duplicates in the view
                        if (pendingLabTests.stream().noneMatch(l -> l.get("id").equals(refId))) {
                            pendingLabTests.add(labInfo);
                        }
                    }
                }
            }
        }
        model.addAttribute("pendingLabTests", pendingLabTests);

        model.addAttribute("pendingPharmacyBills", new ArrayList<>());

        return "receptionist/billing-select";
    }

    @PostMapping("/billing/step2")
    public String processSelection(
            @RequestParam(required = false) String[] selectedAppointments,
            @RequestParam(required = false) String[] selectedLabs,
            HttpSession session, RedirectAttributes redirectAttributes) {
        
        @SuppressWarnings("unchecked")
        Map<String, Object> billingContext = (Map<String, Object>) session.getAttribute("billingContext");
        if (billingContext == null) return "redirect:/receptionist/billing";

        List<String> appts = selectedAppointments != null ? Arrays.asList(selectedAppointments) : new ArrayList<>();
        List<String> labs = selectedLabs != null ? Arrays.asList(selectedLabs) : new ArrayList<>();
        
        if (appts.isEmpty() && labs.isEmpty()) {
            redirectAttributes.addFlashAttribute("errorMessage", "Please select at least one service to bill.");
            return "redirect:/receptionist/billing/select";
        }

        billingContext.put("selectedAppointments", appts);
        billingContext.put("selectedLabs", labs);
        session.setAttribute("billingContext", billingContext);
        
        return "redirect:/receptionist/billing/payment";
    }

    @GetMapping("/billing/payment")
    public String showBillingPayment(Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);
        
        @SuppressWarnings("unchecked")
        Map<String, Object> billingContext = (Map<String, Object>) session.getAttribute("billingContext");
        if (billingContext == null) return "redirect:/receptionist/billing";

        @SuppressWarnings("unchecked")
        List<String> apptIds = (List<String>) billingContext.get("selectedAppointments");
        
        @SuppressWarnings("unchecked")
        List<String> labIds = (List<String>) billingContext.get("selectedLabs");

        @SuppressWarnings("unchecked")
        Map<String, Object> draftAppt = (Map<String, Object>) billingContext.get("draftAppointment");

        double totalApptCost = 0;
        List<Appointment> apptsToBill = new ArrayList<>();
        Map<Long, Double> appointmentFees = new HashMap<>(); 
        
        if (apptIds != null) {
            for (String id : apptIds) {
                Appointment a = appointmentRepository.findById(Long.parseLong(id)).orElse(null);
                if (a != null) {
                    apptsToBill.add(a);
                    Double fee = 500.00;
                    if ("Free Follow up".equalsIgnoreCase(a.getReason())) {
                        fee = 0.0;
                    } else if (a.getDoctor() != null) {
                        DoctorProfile profile = doctorProfileRepository.findByUser(a.getDoctor());
                        if (profile != null && profile.getConsultationFee() != null) {
                            fee = profile.getConsultationFee();
                        }
                    }
                    totalApptCost += fee; 
                    appointmentFees.put(a.getId(), fee);
                }
            }
        }

        if (draftAppt != null) {
            Appointment fakeAppt = new Appointment();
            fakeAppt.setId(-1L);
            fakeAppt.setDepartment((String) draftAppt.get("department"));
            fakeAppt.setAppointmentDate(LocalDate.parse((String) draftAppt.get("appointmentDate")));
            fakeAppt.setAppointmentTime((String) draftAppt.get("appointmentTime"));
            fakeAppt.setReason((String) draftAppt.get("reason"));
            
            DoctorProfile dp = doctorProfileRepository.findById((Long) draftAppt.get("doctorId")).orElse(null);
            if (dp != null) {
                fakeAppt.setDoctor(dp.getUser());
            }
            
            apptsToBill.add(fakeAppt);
            Double fee = (Double) draftAppt.get("fee");
            totalApptCost += fee;
            appointmentFees.put(-1L, fee);
        }

        double totalLabCost = 0;
        List<Map<String, Object>> labsToBill = new ArrayList<>();
        if (labIds != null && !labIds.isEmpty()) {
            List<LabService> labServices = labServiceRepository.findAll();
            for (String refId : labIds) {
                String testName = refId;
                if (refId.contains("_")) {
                    testName = refId.substring(refId.indexOf('_') + 1);
                }
                double cost = 850.0;
                for (LabService ls : labServices) {
                    if (ls.getServiceName().equalsIgnoreCase(testName) && ls.getPrice() != null) {
                        cost = ls.getPrice();
                        break;
                    }
                }
                totalLabCost += cost;
                
                Map<String, Object> labData = new HashMap<>();
                labData.put("id", refId);
                labData.put("name", testName);
                labData.put("cost", cost);
                labsToBill.add(labData);
            }
        }

        model.addAttribute("patientId", billingContext.get("patientId"));
        model.addAttribute("patientName", billingContext.get("patientName"));
        model.addAttribute("appointments", apptsToBill);
        model.addAttribute("appointmentFees", appointmentFees); 
        model.addAttribute("labsToBill", labsToBill);
        model.addAttribute("baseTotal", totalApptCost + totalLabCost);

        return "receptionist/billing-payment";
    }

    @PostMapping("/billing/process")
    public String processPayment(
            @RequestParam Double baseAmount,
            @RequestParam Double cgst,
            @RequestParam Double sgst,
            @RequestParam Double discount,
            @RequestParam String paymentMode,
            @RequestParam String tpin, 
            @RequestParam(required = false) String onlineMethod,
            @RequestParam(required = false) String transactionId,
            @RequestParam(required = false) String transactionDate,
            HttpSession session, RedirectAttributes redirectAttributes) {
        
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        
        @SuppressWarnings("unchecked")
        Map<String, Object> billingContext = (Map<String, Object>) session.getAttribute("billingContext");
        if (billingContext == null) return "redirect:/receptionist/billing";

        try {
            User freshUser = userRepository.findById(loggedInUser.getId()).orElse(null);
            if (freshUser == null || freshUser.gettPin() == null || !freshUser.gettPin().equals(tpin)) {
                redirectAttributes.addFlashAttribute("errorMessage", "Security Validation Failed: Invalid T-Pin. Payment aborted.");
                return "redirect:/receptionist/billing/payment";
            }

            String patientId = (String) billingContext.get("patientId");
            User patient = userRepository.findByUsername(patientId);
            
            LocalDateTime txnDate = null;
            if (transactionDate != null && !transactionDate.isEmpty()) {
                txnDate = LocalDateTime.parse(transactionDate);
            } else {
                txnDate = LocalDateTime.now(ZoneId.of("Asia/Kolkata"));
            }

            @SuppressWarnings("unchecked")
            List<String> apptIds = (List<String>) billingContext.get("selectedAppointments");
            
            @SuppressWarnings("unchecked")
            List<String> labIds = (List<String>) billingContext.get("selectedLabs");

            @SuppressWarnings("unchecked")
            Map<String, Object> draftAppt = (Map<String, Object>) billingContext.get("draftAppointment");

            double totalItems = (apptIds != null ? apptIds.size() : 0) + (labIds != null ? labIds.size() : 0) + (draftAppt != null ? 1 : 0);
            
            List<Long> generatedApptPmtIds = new ArrayList<>();
            List<Long> generatedLabPmtIds = new ArrayList<>();

            if (totalItems > 0) {
                double cgstSplit = (cgst != null ? cgst : 0) / totalItems;
                double sgstSplit = (sgst != null ? sgst : 0) / totalItems;
                double discSplit = (discount != null ? discount : 0) / totalItems;
                
                DateTimeFormatter invFormatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
                String invTimeStr = LocalDateTime.now().format(invFormatter);

                if (draftAppt != null) {
                    DoctorProfile dp = doctorProfileRepository.findById((Long) draftAppt.get("doctorId")).orElse(null);
                    
                    Appointment newAppt = new Appointment();
                    newAppt.setPatient(patient);
                    newAppt.setDoctor(dp != null ? dp.getUser() : null);
                    newAppt.setDepartment((String) draftAppt.get("department"));
                    newAppt.setAppointmentDate(LocalDate.parse((String) draftAppt.get("appointmentDate")));
                    newAppt.setAppointmentTime((String) draftAppt.get("appointmentTime"));
                    newAppt.setReason((String) draftAppt.get("reason"));
                    newAppt.setStatus("SCHEDULED");
                    newAppt.setPaymentStatus("PAID");
                    newAppt.setBookedBy(loggedInUser);
                    
                    Appointment savedAppt = appointmentRepository.save(newAppt);
                    
                    Double baseFee = (Double) draftAppt.get("fee");
                    
                    AppointmentPayment pmt = new AppointmentPayment();
                    pmt.setAppointment(savedAppt);
                    pmt.setPatient(patient);
                    pmt.setBaseAmount(baseFee); 
                    pmt.setCgst(cgstSplit);
                    pmt.setSgst(sgstSplit);
                    pmt.setDiscount(discSplit);
                    pmt.setTotalAmount(baseFee + cgstSplit + sgstSplit - discSplit);
                    pmt.setPaymentMode(paymentMode);
                    pmt.setOnlineMethod(onlineMethod);
                    pmt.setTransactionId(transactionId);
                    pmt.setTransactionDate(txnDate);
                    pmt.setRecordedBy(loggedInUser);
                    
                    AppointmentPayment savedPmt = appointmentPaymentRepository.save(pmt);
                    
                    savedPmt.setInvoiceNumber("INV-" + invTimeStr + "-" + String.format("%04d", savedPmt.getId()));
                    appointmentPaymentRepository.save(savedPmt);
                    
                    generatedApptPmtIds.add(savedPmt.getId());
                }

                if (apptIds != null) {
                    for (String idStr : apptIds) {
                        Appointment appt = appointmentRepository.findById(Long.parseLong(idStr)).orElse(null);
                        if (appt != null) {
                            Double baseFee = 500.00; 
                            if ("Free Follow up".equalsIgnoreCase(appt.getReason())) {
                                baseFee = 0.0;
                            } else if (appt.getDoctor() != null) {
                                DoctorProfile profile = doctorProfileRepository.findByUser(appt.getDoctor());
                                if (profile != null && profile.getConsultationFee() != null) {
                                    baseFee = profile.getConsultationFee();
                                }
                            }

                            appt.setPaymentStatus("PAID");
                            appointmentRepository.save(appt);

                            AppointmentPayment pmt = new AppointmentPayment();
                            pmt.setAppointment(appt);
                            pmt.setPatient(patient);
                            pmt.setBaseAmount(baseFee); 
                            pmt.setCgst(cgstSplit);
                            pmt.setSgst(sgstSplit);
                            pmt.setDiscount(discSplit);
                            pmt.setTotalAmount(baseFee + cgstSplit + sgstSplit - discSplit);
                            pmt.setPaymentMode(paymentMode);
                            pmt.setOnlineMethod(onlineMethod);
                            pmt.setTransactionId(transactionId);
                            pmt.setTransactionDate(txnDate);
                            pmt.setRecordedBy(loggedInUser);
                            
                            AppointmentPayment savedPmt = appointmentPaymentRepository.save(pmt);
                            
                            savedPmt.setInvoiceNumber("INV-" + invTimeStr + "-" + String.format("%04d", savedPmt.getId()));
                            appointmentPaymentRepository.save(savedPmt);
                            
                            generatedApptPmtIds.add(savedPmt.getId());
                        }
                    }
                }

                if (labIds != null) {
                    List<LabService> labServices = labServiceRepository.findAll();
                    for (String labId : labIds) {
                        String testName = labId;
                        if (labId.contains("_")) {
                            testName = labId.substring(labId.indexOf('_') + 1);
                        }
                        double baseCost = 850.0;
                        for (LabService ls : labServices) {
                            if (ls.getServiceName().equalsIgnoreCase(testName) && ls.getPrice() != null) {
                                baseCost = ls.getPrice();
                                break;
                            }
                        }

                        LabPayment lPmt = new LabPayment();
                        lPmt.setLabReferenceId(labId);
                        lPmt.setPatient(patient);
                        lPmt.setBaseAmount(baseCost); 
                        lPmt.setCgst(cgstSplit);
                        lPmt.setSgst(sgstSplit);
                        lPmt.setDiscount(discSplit);
                        lPmt.setTotalAmount(baseCost + cgstSplit + sgstSplit - discSplit);
                        lPmt.setPaymentMode(paymentMode);
                        lPmt.setOnlineMethod(onlineMethod);
                        lPmt.setTransactionId(transactionId);
                        lPmt.setTransactionDate(txnDate);
                        lPmt.setRecordedBy(loggedInUser);
                        lPmt.setStatus("PENDING");
                        
                        LabPayment savedLabPmt = labPaymentRepository.save(lPmt);
                        
                        savedLabPmt.setInvoiceNumber("INV-" + invTimeStr + "-" + String.format("%04d", savedLabPmt.getId()));
                        labPaymentRepository.save(savedLabPmt);
                        
                        generatedLabPmtIds.add(savedLabPmt.getId());
                    }
                }
            }

            session.removeAttribute("billingContext"); 
            
            String redirectUrl = "redirect:/receptionist/billing/receipt?a=" + 
                generatedApptPmtIds.stream().map(String::valueOf).collect(Collectors.joining(",")) + 
                "&l=" + generatedLabPmtIds.stream().map(String::valueOf).collect(Collectors.joining(","));

            return redirectUrl;
            
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error processing payment: " + e.getMessage());
            return "redirect:/receptionist/billing/payment";
        }
    }

    @GetMapping("/billing/receipt")
    public String showReceipt(@RequestParam(required = false) String a, 
                              @RequestParam(required = false) String l,
                              Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        
        List<AppointmentPayment> apptPmts = new ArrayList<>();
        if (a != null && !a.isEmpty()) {
            for (String idStr : a.split(",")) {
                appointmentPaymentRepository.findById(Long.parseLong(idStr)).ifPresent(apptPmts::add);
            }
        }
        
        List<LabPayment> labPmts = new ArrayList<>();
        if (l != null && !l.isEmpty()) {
            for (String idStr : l.split(",")) {
                labPaymentRepository.findById(Long.parseLong(idStr)).ifPresent(labPmts::add);
            }
        }
        
        if (apptPmts.isEmpty() && labPmts.isEmpty()) {
            return "redirect:/receptionist/billing";
        }
        
        double totalBase = 0, totalCgst = 0, totalSgst = 0, totalDiscount = 0, grandTotal = 0;
        User patient = null;
        LocalDateTime txnDate = null;
        String pMode = "", pMethod = "", txnId = "", invoiceNumber = "";
        
        if (!apptPmts.isEmpty()) {
            patient = apptPmts.get(0).getPatient();
            txnDate = apptPmts.get(0).getTransactionDate();
            pMode = apptPmts.get(0).getPaymentMode();
            pMethod = apptPmts.get(0).getOnlineMethod();
            txnId = apptPmts.get(0).getTransactionId();
            invoiceNumber = apptPmts.get(0).getInvoiceNumber();
        } else if (!labPmts.isEmpty()) {
            patient = labPmts.get(0).getPatient();
            txnDate = labPmts.get(0).getTransactionDate();
            pMode = labPmts.get(0).getPaymentMode();
            pMethod = labPmts.get(0).getOnlineMethod();
            txnId = labPmts.get(0).getTransactionId();
            invoiceNumber = labPmts.get(0).getInvoiceNumber();
        }
        
        for(AppointmentPayment p : apptPmts) {
            totalBase += p.getBaseAmount(); totalCgst += p.getCgst(); totalSgst += p.getSgst();
            totalDiscount += p.getDiscount(); grandTotal += p.getTotalAmount();
        }
        
        // Pass map to cleanly render Lab names without ref IDs in the UI
        Map<Long, String> cleanLabNames = new HashMap<>();
        for(LabPayment p : labPmts) {
            totalBase += p.getBaseAmount(); totalCgst += p.getCgst(); totalSgst += p.getSgst();
            totalDiscount += p.getDiscount(); grandTotal += p.getTotalAmount();
            
            String name = p.getLabReferenceId();
            if (name.contains("_")) {
                name = name.substring(name.indexOf('_') + 1);
            }
            cleanLabNames.put(p.getId(), name);
        }
        
        boolean hasActionableTokens = false;
        String todayStr = LocalDate.now(ZoneId.of("Asia/Kolkata")).toString();
        
        for (AppointmentPayment p : apptPmts) {
            String apptStatus = p.getAppointment() != null ? p.getAppointment().getStatus() : "";
            
            // FIX: Removed "COMPLETED" checking. Only check if it is explicitly CLOSED (Dispensed).
            if ("CLOSED".equalsIgnoreCase(apptStatus)) {
                continue;
            }
            if (p.getTokenId() == null) {
                hasActionableTokens = true; break;
            } else if (p.getAppointment() != null && p.getAppointment().getAppointmentDate() != null) {
                if (p.getAppointment().getAppointmentDate().toString().compareTo(todayStr) < 0) {
                    hasActionableTokens = true; break;
                }
            }
        }
        if (!hasActionableTokens) {
            for (LabPayment p : labPmts) {
                String labStatus = p.getStatus() != null ? p.getStatus() : "";
                if ("COMPLETED".equalsIgnoreCase(labStatus) || "CLOSED".equalsIgnoreCase(labStatus)) {
                    continue;
                }
                if (p.getTokenId() == null) {
                    hasActionableTokens = true; break;
                } else if (p.getTransactionDate() != null) {
                    if (p.getTransactionDate().toLocalDate().toString().compareTo(todayStr) < 0) {
                        hasActionableTokens = true; break;
                    }
                }
            }
        }

        model.addAttribute("hasActionableTokens", hasActionableTokens);
        model.addAttribute("patient", patient);
        model.addAttribute("txnDate", txnDate);
        model.addAttribute("pMode", pMode);
        model.addAttribute("pMethod", pMethod);
        model.addAttribute("txnId", txnId);
        model.addAttribute("invoiceNumber", invoiceNumber);
        
        model.addAttribute("apptPmts", apptPmts);
        model.addAttribute("labPmts", labPmts);
        model.addAttribute("cleanLabNames", cleanLabNames);
        
        model.addAttribute("totalBase", totalBase);
        model.addAttribute("totalCgst", totalCgst);
        model.addAttribute("totalSgst", totalSgst);
        model.addAttribute("totalDiscount", totalDiscount);
        model.addAttribute("grandTotal", grandTotal);
        
        return "receptionist/billing-receipt";
    }

    @PostMapping("/api/generate-token")
    @ResponseBody
    public Map<String, Object> generateServiceToken(
            @RequestParam String type, 
            @RequestParam Long paymentId,
            @RequestParam(required = false, defaultValue = "false") boolean regenerate) {
        
        Map<String, Object> response = new HashMap<>();
        try {
            if ("APPOINTMENT".equalsIgnoreCase(type)) {
                AppointmentPayment pmt = appointmentPaymentRepository.findById(paymentId).orElse(null);
                if (pmt != null) {
                    if (pmt.getTokenId() == null || regenerate) {
                        Appointment appt = pmt.getAppointment();
                        
                        if (regenerate && appt != null && !"COMPLETED".equalsIgnoreCase(appt.getStatus())) {
                            VitalSign vitals = vitalSignRepository.findByAppointmentId(appt.getId());
                            if (vitals != null) {
                                vitalSignRepository.delete(vitals);
                            }
                        }

                        String newToken = generateTokenId();
                        
                        pmt.setTokenId(newToken);
                        if (regenerate) {
                            pmt.setTransactionDate(LocalDateTime.now(ZoneId.of("Asia/Kolkata")));
                        }
                        appointmentPaymentRepository.save(pmt);
                        
                        if(appt != null) {
                            appt.setStatus("WAITING"); 
                            appt.setTokenId(newToken);
                            appt.setTokenGeneratedAt(LocalDateTime.now(ZoneId.of("Asia/Kolkata"))); 
                            if (regenerate) {
                                appt.setAppointmentDate(LocalDate.now(ZoneId.of("Asia/Kolkata")));
                            }
                            appointmentRepository.save(appt);
                        }
                        
                        response.put("success", true);
                        response.put("tokenId", newToken);
                    } else {
                        response.put("success", false);
                        response.put("message", "Token already exists.");
                    }
                } else {
                    response.put("success", false);
                    response.put("message", "Payment not found.");
                }
            } else if ("LAB".equalsIgnoreCase(type)) {
                LabPayment pmt = labPaymentRepository.findById(paymentId).orElse(null);
                if (pmt != null) {
                    if (pmt.getTokenId() == null || regenerate) {
                        String newToken = generateTokenId();
                        pmt.setTokenId(newToken);
                        if (regenerate) {
                            pmt.setTransactionDate(LocalDateTime.now(ZoneId.of("Asia/Kolkata")));
                        }
                        labPaymentRepository.save(pmt);
                        
                        response.put("success", true);
                        response.put("tokenId", newToken);
                    } else {
                        response.put("success", false);
                        response.put("message", "Token already exists.");
                    }
                } else {
                    response.put("success", false);
                    response.put("message", "Payment not found.");
                }
            } else {
                response.put("success", false);
                response.put("message", "Invalid token type.");
            }
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
        }
        return response;
    }

    @PostMapping("/api/validate-tpin")
    @ResponseBody
    public Map<String, Object> validateTPinAjax(@RequestParam String tpin, HttpSession session) {
        Map<String, Object> response = new HashMap<>();
        User user = (User) session.getAttribute("loggedInUser");
        if (user != null) {
            User freshUser = userRepository.findById(user.getId()).orElse(null);
            if (freshUser != null && freshUser.gettPin() != null && freshUser.gettPin().equals(tpin)) {
                response.put("valid", true);
                return response;
            }
        }
        response.put("valid", false);
        return response;
    }

    @GetMapping("/api/patient-search")
    @ResponseBody
    public List<Map<String, String>> searchPatients(@RequestParam String query) {
        List<User> patients = userRepository.searchPatients(query);
        List<Map<String, String>> results = new ArrayList<>();
        
        int limit = Math.min(patients.size(), 10);
        for (int i = 0; i < limit; i++) {
            User p = patients.get(i);
            Map<String, String> map = new HashMap<>();
            map.put("id", p.getUsername());
            map.put("name", p.getName());
            map.put("phone", p.getPhoneNumber());
            map.put("text", p.getUsername() + " - " + p.getName());
            results.add(map);
        }
        return results;
    }

    @GetMapping("/api/patient-details")
    @ResponseBody
    public Map<String, Object> getPatientDetails(@RequestParam String patientId) {
        Map<String, Object> response = new HashMap<>();
        User patient = userRepository.findByUsername(patientId);
        
        if (patient != null && "Patient".equalsIgnoreCase(patient.getRole())) {
            response.put("found", true);
            response.put("name", patient.getName());
            if (patient.getPatientProfile() != null) {
                if (patient.getPatientProfile().getDateOfBirth() != null) {
                    response.put("dob", patient.getPatientProfile().getDateOfBirth().format(DateTimeFormatter.ISO_LOCAL_DATE));
                }
                if (patient.getPatientProfile().getGender() != null) {
                    response.put("gender", patient.getPatientProfile().getGender());
                }
                if (patient.getPatientProfile().getBloodGroup() != null) {
                    response.put("bloodGroup", patient.getPatientProfile().getBloodGroup());
                }
            }
        } else {
            response.put("found", false);
            response.put("message", "Patient not found");
        }
        return response;
    }

    @GetMapping("/api/appointment-details")
    @ResponseBody
    public Map<String, Object> getApiAppointmentDetails(@RequestParam Long id) {
        Map<String, Object> response = new HashMap<>();
        try {
            Appointment appointment = appointmentRepository.findById(id).orElse(null);
            if (appointment != null) {
                response.put("found", true);
                response.put("status", appointment.getStatus());
                response.put("patientName", appointment.getPatient() != null ? appointment.getPatient().getName() : "Unknown");
                response.put("patientId", appointment.getPatient() != null ? appointment.getPatient().getUsername() : "N/A");
                response.put("doctorName", appointment.getDoctor() != null ? "Dr. " + appointment.getDoctor().getName() : "Unknown");
                response.put("department", appointment.getDepartment());
                response.put("appointmentDate", appointment.getAppointmentDate() != null ? appointment.getAppointmentDate().toString() : "");
                response.put("appointmentTime", appointment.getAppointmentTime());
                response.put("reason", appointment.getReason() != null ? appointment.getReason() : "N/A");
            } else {
                response.put("found", false);
                response.put("message", "Appointment not found.");
            }
        } catch (Exception e) {
            response.put("found", false);
            response.put("message", "Failed to fetch appointment: " + e.getMessage());
        }
        return response;
    }

    @GetMapping("/api/doctors-by-department")
    @ResponseBody
    public List<Map<String, String>> getDoctorsByDepartment(@RequestParam String department) {
        List<DoctorProfile> doctors = doctorProfileRepository.findByDepartment(department);
        List<Map<String, String>> result = new ArrayList<>();
        
        for (DoctorProfile dp : doctors) {
            Map<String, String> map = new HashMap<>();
            map.put("id", dp.getId().toString());
            map.put("name", "Dr. " + dp.getUser().getName());
            map.put("fee", dp.getConsultationFee() != null ? dp.getConsultationFee().toString() : "0.0");
            map.put("timings", dp.getAvailabilityTimings() != null ? dp.getAvailabilityTimings() : "");
            result.add(map);
        }
        return result;
    }

    @GetMapping("/api/doctor-slots")
    @ResponseBody
    public List<Map<String, Object>> getDoctorSlots(@RequestParam Long doctorId, @RequestParam String date) {
        List<Map<String, Object>> availableSlots = new ArrayList<>();
        
        try {
            LocalDate selectedDate = LocalDate.parse(date);
            ZoneId istZone = ZoneId.of("Asia/Kolkata");
            LocalDate today = LocalDate.now(istZone);

            if (selectedDate.isBefore(today)) {
                return availableSlots; 
            }

            DoctorProfile doctorProfile = doctorProfileRepository.findById(doctorId).orElse(null);
            if (doctorProfile == null) return availableSlots;

            LocalTime startTime = null;
            LocalTime endTime = null;

            String timings = doctorProfile.getAvailabilityTimings();
            String dayOfWeekShort = selectedDate.getDayOfWeek().getDisplayName(TextStyle.SHORT, Locale.ENGLISH);

            if (timings != null && !timings.trim().isEmpty() && !"Not Specified".equalsIgnoreCase(timings.trim())) {
                try {
                    if (timings.contains("|") || timings.matches(".*[A-Za-z]{3}:.*")) {
                        String[] dayParts = timings.split("\\|");
                        for (String dayPart : dayParts) {
                            if (dayPart.trim().startsWith(dayOfWeekShort)) {
                                String timeRange = dayPart.substring(dayPart.indexOf(":") + 1).trim();
                                String[] bounds = timeRange.split("-");
                                if (bounds.length >= 2) {
                                    startTime = parseRobustTime(bounds[0]);
                                    endTime = parseRobustTime(bounds[1]);
                                }
                                break;
                            }
                        }
                    } else {
                        String[] parts = timings.split("(?i)\\s*-\\s*|\\s+to\\s+");
                        if (parts.length >= 2) {
                            startTime = parseRobustTime(parts[0]);
                            endTime = parseRobustTime(parts[1]);
                        }
                    }
                } catch (Exception e) {
                    System.err.println("Warning: Failed to parse timings '" + timings + "' for Doctor ID: " + doctorId + " -> " + e.getMessage());
                }
            }

            if (startTime == null || endTime == null) {
                return availableSlots;
            }

            LocalTime currentTime = startTime;
            LocalTime now = LocalTime.now(istZone);
            DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("hh:mm a");

            while (currentTime.isBefore(endTime)) {
                if (selectedDate.isEqual(today) && currentTime.isBefore(now)) {
                    currentTime = currentTime.plusMinutes(30);
                    continue;
                }

                String timeString = currentTime.format(timeFormatter);
                long bookedCount = appointmentRepository.countByDoctorAndAppointmentDateAndAppointmentTimeAndStatusNot(
                    doctorProfile.getUser(), selectedDate, timeString, "CANCELLED"
                );

                Map<String, Object> slotData = new HashMap<>();
                slotData.put("timeValue", timeString);
                slotData.put("displayLabel", timeString + " (" + bookedCount + " booked)");
                
                availableSlots.add(slotData);

                currentTime = currentTime.plusMinutes(30);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return availableSlots;
    }

    private LocalTime parseRobustTime(String timeStr) {
        timeStr = timeStr.trim().toUpperCase().replaceAll("\\s+", "");
        try {
            if (timeStr.contains("AM") || timeStr.contains("PM")) {
                if (!timeStr.contains(":")) {
                    timeStr = timeStr.replace("AM", ":00AM").replace("PM", ":00PM");
                }
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("h:mma");
                return LocalTime.parse(timeStr, formatter);
            } else {
                if (!timeStr.contains(":")) {
                    timeStr += ":00";
                }
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("H:mm");
                return LocalTime.parse(timeStr, formatter);
            }
        } catch (Exception e) {
            throw new RuntimeException("Unparseable fragment: " + timeStr);
        }
    }

    private boolean isLoggedIn(HttpSession session) {
        return session.getAttribute("loggedInUser") != null;
    }

    private void addUserAttributes(Model model, HttpSession session) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user != null) {
            model.addAttribute("name", user.getName());
            model.addAttribute("username", user.getUsername());
            model.addAttribute("role", user.getRole());
        }
    }
}