package com.osacare.myapp.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.osacare.myapp.entity.Department;
import com.osacare.myapp.repository.DepartmentRepository;

@Service
public class DepartmentService {

    private final DepartmentRepository departmentRepository;

    public DepartmentService(DepartmentRepository departmentRepository) {
        this.departmentRepository = departmentRepository;
    }

    public List<Department> getAllDepartments() {
        return departmentRepository.findAll();
    }

    public Department addDepartment(String name) {
        if (departmentRepository.existsByNameIgnoreCase(name)) {
            throw new IllegalArgumentException("Specialization/Department already exists.");
        }
        Department dept = new Department();
        dept.setName(name.trim());
        return departmentRepository.save(dept);
    }
}