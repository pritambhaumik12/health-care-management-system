package com.osacare.myapp.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.osacare.myapp.entity.DoctorProfile;
import com.osacare.myapp.entity.PatientProfile;
import com.osacare.myapp.entity.User;
import com.osacare.myapp.repository.UserRepository;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

@Service
@Transactional
public class UserService {

    private final UserRepository userRepository;
    private final Random random = new Random();
    
    private String lastGeneratedPatientId = null;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    private synchronized String generateSystemId(String role) {
        if ("Patient".equals(role)) {
            return generateSequentialPatientId();
        }

        String prefix = "OSA-USR-";
        if (role != null) {
            switch (role) {
                case "Doctor": prefix = "OSA-DOC-"; break;
                case "Admin": prefix = "OSA-ADM-"; break;
                case "Receptionist": prefix = "OSA-REC-"; break;
                case "Diagnostic Lab": prefix = "OSA-LAB-"; break;
                case "Pharmacy": prefix = "OSA-PHA-"; break;
                case "Help Team": prefix = "OSA-HLP-"; break;
                case "Insurance Team": prefix = "OSA-INS-"; break;
                case "VSOP": prefix = "OSA-VSP-"; break;
            }
        }
        return prefix + UUID.randomUUID().toString().substring(0, 6).toUpperCase();
    }

    private String generateSequentialPatientId() {
        if (lastGeneratedPatientId == null) {
            User lastPatient = userRepository.findFirstByRoleOrderByIdDesc("Patient");
            if (lastPatient != null && lastPatient.getUsername() != null && lastPatient.getUsername().startsWith("OSA-PAT-")) {
                lastGeneratedPatientId = lastPatient.getUsername();
            } else {
                lastGeneratedPatientId = "OSA-PAT-" + generateRandomLetters(2) + "00000000"; 
            }
        }

        String suffix = lastGeneratedPatientId.substring("OSA-PAT-".length());
        String letters = suffix.substring(0, 2);
        long number = 0;
        
        try {
            number = Long.parseLong(suffix.substring(2));
        } catch (NumberFormatException e) {
            letters = generateRandomLetters(2);
            number = 0;
        }

        do {
            number++;
            if (number > 99990001L) {
                letters = generateRandomLetters(2);
                number = 1;
            }
            lastGeneratedPatientId = String.format("OSA-PAT-%s%08d", letters, number);
            
        } while (userRepository.findByUsername(lastGeneratedPatientId) != null); 

        return lastGeneratedPatientId;
    }

    private String generateRandomLetters(int length) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            sb.append((char) ('A' + random.nextInt(26)));
        }
        return sb.toString();
    }

    private void populatePatientProfileFields(PatientProfile pp, Map<String, String> params) {
        if (params.get("birthYear") != null && !params.get("birthYear").isEmpty()) {
            pp.setBirthYear(Integer.parseInt(params.get("birthYear")));
        }
        
        // Parse and save the full Date of Birth
        String dobStr = params.get("dateOfBirth");
        if (dobStr != null && !dobStr.trim().isEmpty()) {
            try {
                pp.setDateOfBirth(LocalDate.parse(dobStr)); // Parses "YYYY-MM-DD" natively
            } catch (DateTimeParseException e) {
                // Log or handle invalid date formats if necessary
            }
        }

        pp.setGender(params.get("patientGender"));
        pp.setBloodGroup(params.get("patientBloodGroup"));
        pp.setAddress(params.get("patientAddress"));
        
        pp.setNationalIdName(params.get("nationalIdName"));
        String nid = params.get("nationalIdNumber");
        if(nid != null && !nid.trim().isEmpty()) {
            pp.setNationalIdNumber(nid);
        } else {
            pp.setNationalIdNumber(null); // Prevent unique constraint issues on empty strings
        }

        pp.setEmergencyContactName(params.get("emergencyContactName"));
        pp.setEmergencyContactNumber(params.get("emergencyContactNumber"));
        pp.setEmergencyContactAddress(params.get("emergencyContactAddress"));
        
        pp.setChiefComplaint(params.get("chiefComplaint"));
        pp.setIllnessHistory(params.get("illnessHistory"));
        pp.setSurgicalHistory(params.get("surgicalHistory"));
        pp.setAllergies(params.get("allergies"));
        pp.setFamilyHistory(params.get("familyHistory"));
    }

    // Refactored to accept Map to easily retrieve dynamic form fields
    public User registerUser(Map<String, String> params) {
        String email = params.get("email");
        if (userRepository.findByEmail(email) != null) {
            return null; 
        }
        
        String role = params.get("role");
        String generatedUsername;
        do {
            generatedUsername = generateSystemId(role);
        } while (userRepository.findByUsername(generatedUsername) != null);
        
        User user = new User();
        user.setFirstName(params.get("firstName"));
        user.setLastName(params.get("lastName"));
        user.setEmail(email);
        user.setPhoneNumber(params.get("phoneNumber"));
        user.setUsername(generatedUsername); 
        user.setPassword(params.get("password")); 
        user.setRole(role); 
        user.setActive(true);
        
        if ("Patient".equals(role)) {
            PatientProfile pp = new PatientProfile();
            pp.setUser(user);
            pp.setPatientIdNumber(generatedUsername);
            populatePatientProfileFields(pp, params);
            user.setPatientProfile(pp);
        } else if ("Doctor".equals(role)) {
            DoctorProfile dp = new DoctorProfile();
            dp.setUser(user);
            dp.setDoctorIdNumber(generatedUsername);
            user.setDoctorProfile(dp);
        }
        
        return userRepository.save(user);
    }

    public User createUserByAdmin(Map<String, String> params) {
        String email = params.get("email");
        if (userRepository.findByEmail(email) != null) {
            return null; 
        }
        
        String role = params.get("role");
        String generatedUsername;
        do {
            generatedUsername = generateSystemId(role);
        } while (userRepository.findByUsername(generatedUsername) != null);
        
        User user = new User();
        user.setFirstName(params.get("firstName"));
        user.setLastName(params.get("lastName"));
        user.setEmail(email);
        user.setPhoneNumber(params.get("phoneNumber"));
        user.setUsername(generatedUsername); 
        user.setPassword(generatedUsername); // Default password as username for Admin creates
        user.setRole(role); 
        user.setActive(true);
        
        if ("Patient".equals(role)) {
            PatientProfile pp = new PatientProfile();
            pp.setUser(user);
            pp.setPatientIdNumber(generatedUsername);
            populatePatientProfileFields(pp, params);
            user.setPatientProfile(pp);
            
        } else if ("Doctor".equals(role)) {
            DoctorProfile dp = new DoctorProfile();
            dp.setUser(user);
            dp.setDoctorIdNumber(generatedUsername);
            dp.setDepartment(params.get("doctorSpecialization"));
            dp.setMedicalLicenseNumber(params.get("doctorLicense"));
            dp.setQualifications(params.get("doctorQualifications"));
            
            if (params.get("doctorExperience") != null && !params.get("doctorExperience").isEmpty()) {
                dp.setYearsOfExperience(Integer.parseInt(params.get("doctorExperience")));
            }
            if (params.get("doctorFee") != null && !params.get("doctorFee").isEmpty()) {
                dp.setConsultationFee(Double.parseDouble(params.get("doctorFee")));
            }
            dp.setAssignedCabin(params.get("doctorCabin"));
            
            StringBuilder timingsStr = new StringBuilder();
            String[] days = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"};
            for (String day : days) {
                if ("true".equals(params.get("timing_" + day + "_active"))) {
                    String start = params.get("timing_" + day + "_start");
                    String end = params.get("timing_" + day + "_end");
                    if (start != null && end != null && !start.isEmpty() && !end.isEmpty()) {
                        if (timingsStr.length() > 0) timingsStr.append(" | ");
                        timingsStr.append(day).append(": ").append(start).append("-").append(end);
                    }
                }
            }
            dp.setAvailabilityTimings(timingsStr.length() > 0 ? timingsStr.toString() : "Not Specified");
            user.setDoctorProfile(dp);
        }
        
        return userRepository.save(user);
    }

    public User updateUserByAdmin(Long id, Map<String, String> params) {
        Optional<User> userOpt = userRepository.findById(id);
        if (!userOpt.isPresent()) return null;

        User user = userOpt.get();
        
        user.setName(params.get("name"));
        user.setEmail(params.get("email"));
        user.setPhoneNumber(params.get("phoneNumber"));
        
        String newRole = params.get("role");
        user.setRole(newRole);
        user.setActive(Boolean.parseBoolean(params.get("active")));

        if ("Patient".equals(newRole)) {
            PatientProfile pp = user.getPatientProfile();
            if (pp == null) {
                pp = new PatientProfile();
                pp.setUser(user);
                pp.setPatientIdNumber(user.getUsername()); 
            }
            populatePatientProfileFields(pp, params);
            user.setPatientProfile(pp);
            
        } else if ("Doctor".equals(newRole)) {
            DoctorProfile dp = user.getDoctorProfile();
            if (dp == null) {
                dp = new DoctorProfile();
                dp.setUser(user);
                dp.setDoctorIdNumber(user.getUsername());
            }
            dp.setDepartment(params.get("doctorSpecialization"));
            dp.setMedicalLicenseNumber(params.get("doctorLicense"));
            dp.setQualifications(params.get("doctorQualifications"));
            
            if (params.get("doctorExperience") != null && !params.get("doctorExperience").isEmpty()) {
                dp.setYearsOfExperience(Integer.parseInt(params.get("doctorExperience")));
            }
            if (params.get("doctorFee") != null && !params.get("doctorFee").isEmpty()) {
                dp.setConsultationFee(Double.parseDouble(params.get("doctorFee")));
            }
            dp.setAssignedCabin(params.get("doctorCabin"));
            
            StringBuilder timingsStr = new StringBuilder();
            String[] days = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"};
            for (String day : days) {
                if ("true".equals(params.get("timing_" + day + "_active"))) {
                    String start = params.get("timing_" + day + "_start");
                    String end = params.get("timing_" + day + "_end");
                    if (start != null && end != null && !start.isEmpty() && !end.isEmpty()) {
                        if (timingsStr.length() > 0) timingsStr.append(" | ");
                        timingsStr.append(day).append(": ").append(start).append("-").append(end);
                    }
                }
            }
            dp.setAvailabilityTimings(timingsStr.length() > 0 ? timingsStr.toString() : "Not Specified");
            user.setDoctorProfile(dp);
        }

        return userRepository.save(user);
    }

    @Transactional(readOnly = true)
    public User authenticate(String username, String password) {
        User user = userRepository.findByUsername(username);
        if (user != null && user.getPassword().equals(password) && user.isActive()) {
            return user;
        }
        return null;
    }

    @Transactional(readOnly = true)
    public List<User> getAllUsers() {
        return userRepository.findAllByOrderByIdDesc();
    }

    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }
    
    @Transactional(readOnly = true)
    public User getUserById(Long id) {
        Optional<User> user = userRepository.findById(id);
        return user.orElse(null);
    }

    public boolean updatePassword(Long id, String newPassword) {
        Optional<User> userOpt = userRepository.findById(id);
        if (userOpt.isPresent()) {
            User existingUser = userOpt.get();
            existingUser.setPassword(newPassword);
            userRepository.save(existingUser);
            return true;
        }
        return false;
    }

    public boolean toggleUserStatus(Long id) {
        Optional<User> userOpt = userRepository.findById(id);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            user.setActive(!user.isActive());
            userRepository.save(user);
            return user.isActive();
        }
        return false;
    }
}