package com.osacare.myapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.osacare.myapp.entity.ResultDuration;

@Repository
public interface ResultDurationRepository extends JpaRepository<ResultDuration, Long> {
}