package com.osacare.myapp.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "lab_payments")
public class LabPayment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String invoiceNumber;
    private String tokenId;
    private String labReferenceId;

    @ManyToOne
    @JoinColumn(name = "patient_id")
    private User patient;

    private Double baseAmount;
    private Double cgst;
    private Double sgst;
    private Double discount;
    private Double totalAmount;
    private String paymentMode;
    private String onlineMethod;
    private String transactionId;
    private LocalDateTime transactionDate;
    
    @Column(name = "scheduled_date_time")
    private LocalDateTime scheduledDateTime;

    @ManyToOne
    @JoinColumn(name = "recorded_by")
    private User recordedBy;

    private String status;
    
    @Column(columnDefinition = "TEXT")
    private String reportData;

    private LocalDateTime sampleCollectedDate;
    private LocalDateTime resultPublishedDate;

    private String batchId;
    private String collectionMethod;
    private String sampleTakerName;
    
    // NEW FIELD: Added for Sample ID tracking during Collection Workflow
    private String sampleId;

    public LabPayment() {}

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getInvoiceNumber() { return invoiceNumber; }
    public void setInvoiceNumber(String invoiceNumber) { this.invoiceNumber = invoiceNumber; }

    public String getTokenId() { return tokenId; }
    public void setTokenId(String tokenId) { this.tokenId = tokenId; }

    public String getLabReferenceId() { return labReferenceId; }
    public void setLabReferenceId(String labReferenceId) { this.labReferenceId = labReferenceId; }

    public User getPatient() { return patient; }
    public void setPatient(User patient) { this.patient = patient; }

    public Double getBaseAmount() { return baseAmount; }
    public void setBaseAmount(Double baseAmount) { this.baseAmount = baseAmount; }

    public Double getCgst() { return cgst; }
    public void setCgst(Double cgst) { this.cgst = cgst; }

    public Double getSgst() { return sgst; }
    public void setSgst(Double sgst) { this.sgst = sgst; }

    public Double getDiscount() { return discount; }
    public void setDiscount(Double discount) { this.discount = discount; }

    public Double getTotalAmount() { return totalAmount; }
    public void setTotalAmount(Double totalAmount) { this.totalAmount = totalAmount; }

    public String getPaymentMode() { return paymentMode; }
    public void setPaymentMode(String paymentMode) { this.paymentMode = paymentMode; }

    public String getOnlineMethod() { return onlineMethod; }
    public void setOnlineMethod(String onlineMethod) { this.onlineMethod = onlineMethod; }

    public String getTransactionId() { return transactionId; }
    public void setTransactionId(String transactionId) { this.transactionId = transactionId; }

    public LocalDateTime getTransactionDate() { return transactionDate; }
    public void setTransactionDate(LocalDateTime transactionDate) { this.transactionDate = transactionDate; }
    
    public LocalDateTime getScheduledDateTime() { return scheduledDateTime; }
    public void setScheduledDateTime(LocalDateTime scheduledDateTime) { this.scheduledDateTime = scheduledDateTime; }

    public User getRecordedBy() { return recordedBy; }
    public void setRecordedBy(User recordedBy) { this.recordedBy = recordedBy; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getReportData() { return reportData; }
    public void setReportData(String reportData) { this.reportData = reportData; }

    public LocalDateTime getSampleCollectedDate() { return sampleCollectedDate; }
    public void setSampleCollectedDate(LocalDateTime sampleCollectedDate) { this.sampleCollectedDate = sampleCollectedDate; }

    public LocalDateTime getResultPublishedDate() { return resultPublishedDate; }
    public void setResultPublishedDate(LocalDateTime resultPublishedDate) { this.resultPublishedDate = resultPublishedDate; }

    public String getBatchId() { return batchId; }
    public void setBatchId(String batchId) { this.batchId = batchId; }

    public String getCollectionMethod() { return collectionMethod; }
    public void setCollectionMethod(String collectionMethod) { this.collectionMethod = collectionMethod; }

    public String getSampleTakerName() { return sampleTakerName; }
    public void setSampleTakerName(String sampleTakerName) { this.sampleTakerName = sampleTakerName; }

    public String getSampleId() { return sampleId; }
    public void setSampleId(String sampleId) { this.sampleId = sampleId; }
}