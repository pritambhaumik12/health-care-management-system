package com.osacare.myapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.osacare.myapp.entity.Appointment;
import com.osacare.myapp.entity.AppointmentPayment;

@Repository
public interface AppointmentPaymentRepository extends JpaRepository<AppointmentPayment, Long> {
    
    // Fetch all appointment payments ordered by transaction date descending
    List<AppointmentPayment> findAllByOrderByTransactionDateDesc();
    
    // Find payment by exact token string (used in the scanner)
    AppointmentPayment findByTokenId(String tokenId);
    
    // Find payment linked to a specific appointment (used in the capture page)
    AppointmentPayment findByAppointment(Appointment appointment);
}