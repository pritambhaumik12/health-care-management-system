package com.osacare.myapp.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

// Add Jackson imports for JSON parsing
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.osacare.myapp.entity.Appointment;
import com.osacare.myapp.entity.HospitalDetails;
import com.osacare.myapp.entity.LabPayment;
import com.osacare.myapp.entity.LabService;
import com.osacare.myapp.entity.ResultDuration;
import com.osacare.myapp.entity.User;
import com.osacare.myapp.repository.AppointmentRepository;
import com.osacare.myapp.repository.HospitalDetailsRepository;
import com.osacare.myapp.repository.LabPaymentRepository;
import com.osacare.myapp.repository.LabServiceRepository;
import com.osacare.myapp.repository.ResultDurationRepository;
import com.osacare.myapp.repository.UserRepository;
import com.osacare.myapp.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/lab")
public class LabController {

    @Autowired
    private LabServiceRepository labServiceRepository;

    @Autowired
    private ResultDurationRepository durationRepository;

    @Autowired
    private LabPaymentRepository labPaymentRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AppointmentRepository appointmentRepository;
    
    @Autowired
    private HospitalDetailsRepository hospitalDetailsRepository;

    @Autowired
    private UserService userService;

    private boolean isLoggedIn(HttpSession session) {
        return session.getAttribute("loggedInUser") != null;
    }

    private void addUserAttributes(Model model, HttpSession session) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user != null) {
            model.addAttribute("name", user.getName());
            model.addAttribute("username", user.getUsername());
            model.addAttribute("role", user.getRole());
        }
    }

    private String generateTokenId() {
        String letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String numbers = "0123456789";
        Random rnd = new Random();
        return "L-" + letters.charAt(rnd.nextInt(letters.length()))
                  + numbers.charAt(rnd.nextInt(numbers.length()))
                  + letters.charAt(rnd.nextInt(letters.length()))
                  + numbers.charAt(rnd.nextInt(numbers.length()));
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);
        
        List<HospitalDetails> hdList = hospitalDetailsRepository.findAll();
        if (!hdList.isEmpty()) {
            model.addAttribute("hospitalDetails", hdList.get(0));
        }
        
        return "lab/dashboard";
    }

    // ==========================================
    // 1. MANAGE SERVICES
    // ==========================================
    @GetMapping("/services")
    public String listServices(Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);
        model.addAttribute("services", labServiceRepository.findAllByOrderByServiceNameAsc());
        return "lab/services";
    }

    @PostMapping("/services/{id}/toggle-status")
    public String toggleServiceStatus(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            LabService service = labServiceRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid service Id:" + id));
            service.setActive(!service.isActive());
            labServiceRepository.save(service);
            redirectAttributes.addFlashAttribute("successMessage", "Service status updated.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error: " + e.getMessage());
        }
        return "redirect:/lab/services"; 
    }

    @GetMapping("/add-service")
    public String showAddServiceForm(Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);
        if (!model.containsAttribute("labService")) {
            model.addAttribute("labService", new LabService());
        }
        if (durationRepository.count() == 0) {
            durationRepository.save(new ResultDuration("Same Day (Within 4 hours)"));
            durationRepository.save(new ResultDuration("24 Hours"));
        }
        model.addAttribute("durations", durationRepository.findAll());
        return "lab/add-service";
    }

    @PostMapping("/add-service")
    public String processAddServiceForm(@ModelAttribute("labService") LabService labService, @RequestParam Map<String, String> allParams, RedirectAttributes redirectAttributes) {
        try {
            String[] days = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"};
            StringBuilder builder = new StringBuilder();
            for (String day : days) {
                if ("true".equals(allParams.get("timing_" + day + "_active"))) {
                    if (builder.length() > 0) builder.append(" | ");
                    builder.append(day).append(": ").append(allParams.get("timing_" + day + "_start")).append(" - ").append(allParams.get("timing_" + day + "_end"));
                }
            }
            labService.setAvailabilityTimings(builder.toString());
            labServiceRepository.save(labService);
            redirectAttributes.addFlashAttribute("successMessage", "Service added!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error: " + e.getMessage());
        }
        return "redirect:/lab/add-service"; 
    }

    // ==========================================
    // 2. VIEW LAB REQUESTS
    // ==========================================
    @GetMapping("/requests")
    public String viewLabRequests(@RequestParam(required = false) String status, @RequestParam(required = false) String date, Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);
        
        List<LabPayment> allPayments = labPaymentRepository.findAll();
        List<Appointment> allAppointments = appointmentRepository.findAll();
        List<Map<String, Object>> unifiedRequests = new ArrayList<>();
        
        for (LabPayment req : allPayments) {
            Map<String, Object> map = new HashMap<>();
            map.put("paymentId", req.getId()); 
            map.put("invoiceNumber", req.getInvoiceNumber() != null ? req.getInvoiceNumber() : "N/A");
            map.put("patientName", req.getPatient() != null ? req.getPatient().getName() : "Unknown");
            map.put("patientId", req.getPatient() != null ? req.getPatient().getUsername() : "Unknown");
            
            String refId = req.getLabReferenceId();
            String testName = refId;
            String doctorName = "N/A";

            if (refId != null && refId.contains("_")) {
                String[] parts = refId.split("_", 2);
                try {
                    Long apptId = Long.parseLong(parts[0]);
                    Appointment appt = allAppointments.stream().filter(a -> a.getId().equals(apptId)).findFirst().orElse(null);
                    if (appt != null && appt.getDoctor() != null) {
                        doctorName = "Dr. " + appt.getDoctor().getName();
                    }
                } catch (NumberFormatException e) {}
                testName = parts[1];
            }
            map.put("doctorName", doctorName);
            map.put("testName", testName);
            map.put("transactionDate", req.getTransactionDate());
            map.put("status", req.getStatus());
            unifiedRequests.add(map);
        }
        
        for (Appointment appt : allAppointments) {
            if (appt.getPrescription() != null) {
                java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\[Lab Test Prescribed: (.*?)\\]").matcher(appt.getPrescription());
                while (m.find()) {
                    String testName = m.group(1).trim();
                    String refId = appt.getId() + "_" + testName;
                    boolean alreadyBilled = allPayments.stream().anyMatch(lp -> refId.equals(lp.getLabReferenceId()));
                    if (!alreadyBilled) {
                        Map<String, Object> map = new HashMap<>();
                        map.put("paymentId", null);
                        map.put("invoiceNumber", "UNPAID");
                        map.put("patientName", appt.getPatient() != null ? appt.getPatient().getName() : "Unknown");
                        map.put("patientId", appt.getPatient() != null ? appt.getPatient().getUsername() : "Unknown");
                        map.put("doctorName", appt.getDoctor() != null ? "Dr. " + appt.getDoctor().getName() : "Unknown");
                        map.put("testName", testName);
                        map.put("transactionDate", appt.getAppointmentDate() != null ? appt.getAppointmentDate().atStartOfDay() : null);
                        map.put("status", "UNPAID");
                        unifiedRequests.add(map);
                    }
                }
            }
        }

        if (date != null && !date.isEmpty()) {
            LocalDate searchDate = LocalDate.parse(date);
            unifiedRequests = unifiedRequests.stream()
                .filter(req -> {
                    Object td = req.get("transactionDate");
                    if (td instanceof LocalDateTime) {
                        return ((LocalDateTime) td).toLocalDate().isEqual(searchDate);
                    }
                    return false;
                })
                .collect(Collectors.toList());
            model.addAttribute("selectedDate", date);
        }

        if (status != null && !status.isEmpty() && !"ALL".equalsIgnoreCase(status)) {
            unifiedRequests = unifiedRequests.stream()
                .filter(req -> status.equalsIgnoreCase((String) req.get("status")))
                .collect(Collectors.toList());
            model.addAttribute("selectedStatus", status);
        }
        
        unifiedRequests.sort((a, b) -> {
            LocalDateTime dateA = (LocalDateTime) a.get("transactionDate");
            LocalDateTime dateB = (LocalDateTime) b.get("transactionDate");
            if (dateA == null && dateB == null) return 0;
            if (dateA == null) return 1;
            if (dateB == null) return -1;
            return dateB.compareTo(dateA);
        });

        model.addAttribute("labRequests", unifiedRequests);
        return "lab/requests";
    }

    // ==========================================
    // 3. TODAY'S QUEUE & DETAILS
    // ==========================================
    @GetMapping("/queue")
    public String viewTodayQueue(Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);

        LocalDate today = LocalDate.now(ZoneId.of("Asia/Kolkata"));
        List<Appointment> allAppointments = appointmentRepository.findAll();
        
        List<LabPayment> todaysPayments = labPaymentRepository.findAll().stream()
            .filter(req -> req.getScheduledDateTime() != null && req.getScheduledDateTime().toLocalDate().isEqual(today))
            .filter(req -> req.getTokenId() != null && !req.getTokenId().isEmpty())
            .filter(req -> !"COMPLETED".equalsIgnoreCase(req.getStatus()) && !"CLOSED".equalsIgnoreCase(req.getStatus()))
            .collect(Collectors.toList());

        List<Map<String, Object>> queueData = new ArrayList<>();
        
        for(LabPayment pmt : todaysPayments) {
            Map<String, Object> map = new HashMap<>();
            map.put("id", pmt.getId());
            map.put("patientId", pmt.getPatient() != null ? pmt.getPatient().getUsername() : "N/A");
            map.put("patientName", pmt.getPatient() != null ? pmt.getPatient().getName() : "Unknown");
            map.put("status", pmt.getStatus());
            map.put("tokenId", pmt.getTokenId());
            
            String doctorName = "N/A";
            String testName = pmt.getLabReferenceId();
            if (testName != null && testName.contains("_")) {
                String[] parts = testName.split("_", 2);
                try {
                    Long apptId = Long.parseLong(parts[0]);
                    Appointment appt = allAppointments.stream().filter(a -> a.getId().equals(apptId)).findFirst().orElse(null);
                    if (appt != null && appt.getDoctor() != null) {
                        doctorName = "Dr. " + appt.getDoctor().getName();
                    }
                } catch (Exception e) {}
                testName = parts[1];
            }
            map.put("doctorName", doctorName);
            map.put("testName", testName);
            map.put("date", pmt.getScheduledDateTime());
            queueData.add(map);
        }

        model.addAttribute("queue", queueData);
        return "lab/queue";
    }

    @GetMapping("/queue/details/{id}")
    public String queueDetails(@PathVariable Long id, Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);
        
        LabPayment pmt = labPaymentRepository.findById(id).orElse(null);
        if(pmt == null) return "redirect:/lab/queue";
        
        String doctorName = "Self/Direct";
        String prescriptionText = "No specific prescription attached or Direct Lab Walk-in.";
        String testName = pmt.getLabReferenceId();
        
        Long apptIdForModal = null;
        LocalDateTime prescribedDate = null;
        
        if (testName != null && testName.contains("_")) {
            String[] parts = testName.split("_", 2);
            try {
                Long apptId = Long.parseLong(parts[0]);
                apptIdForModal = apptId;
                Appointment appt = appointmentRepository.findById(apptId).orElse(null);
                if (appt != null) {
                    if (appt.getDoctor() != null) doctorName = "Dr. " + appt.getDoctor().getName();
                    if (appt.getPrescription() != null && !appt.getPrescription().isEmpty()) {
                        prescriptionText = appt.getPrescription();
                    }
                    if (appt.getAppointmentDate() != null) {
                        prescribedDate = appt.getAppointmentDate().atStartOfDay();
                    }
                }
            } catch (Exception e) {}
            testName = parts[1];
        }
        
        model.addAttribute("payment", pmt);
        model.addAttribute("testName", testName);
        model.addAttribute("doctorName", doctorName);
        model.addAttribute("prescriptionText", prescriptionText);
        model.addAttribute("apptId", apptIdForModal);
        model.addAttribute("prescribedDate", prescribedDate);
        
        return "lab/queue-details";
    }

    @PostMapping("/queue/update-status/{id}")
    @ResponseBody
    public Map<String, Object> updateQueueStatus(@PathVariable Long id, @RequestBody Map<String, String> payload, HttpSession session) {
        Map<String, Object> response = new HashMap<>();
        if (!isLoggedIn(session)) {
            response.put("success", false);
            response.put("message", "Session expired. Please log in.");
            return response;
        }
        try {
            LabPayment pmt = labPaymentRepository.findById(id).orElseThrow(() -> new RuntimeException("Lab request not found"));
            pmt.setStatus(payload.get("status"));
            labPaymentRepository.save(pmt);
            response.put("success", true);
            response.put("message", "Test status updated successfully.");
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
        }
        return response;
    }

    // ==========================================
    // 4. ADVANCED BILLING SYSTEM & SCHEDULING
    // ==========================================
    @GetMapping("/api/lab-slots")
    @ResponseBody
    public Map<String, Object> getLabSlots(@RequestParam String testName, @RequestParam String dateStr) {
        Map<String, Object> response = new HashMap<>();
        try {
            LocalDate date = LocalDate.parse(dateStr);
            String dayOfWeek = date.getDayOfWeek().getDisplayName(java.time.format.TextStyle.SHORT, java.util.Locale.ENGLISH); 
            
            LabService service = labServiceRepository.findAll().stream()
                .filter(s -> s.getServiceName().equalsIgnoreCase(testName))
                .findFirst().orElse(null);
                
            if (service == null || service.getAvailabilityTimings() == null || service.getAvailabilityTimings().isEmpty()) {
                response.put("success", false);
                response.put("message", "Service not found or no timing configuration available.");
                return response;
            }
            
            String timings = service.getAvailabilityTimings();
            String dayTiming = null;
            for (String t : timings.split("\\|")) {
                if (t.trim().startsWith(dayOfWeek)) {
                    dayTiming = t.trim().substring(t.indexOf(':') + 1).trim(); 
                    break;
                }
            }
            
            if (dayTiming == null || dayTiming.isEmpty()) {
                response.put("success", true);
                response.put("slots", new ArrayList<>());
                return response;
            }
            
            String[] times = dayTiming.split("-");
            LocalTime startTime = LocalTime.parse(times[0].trim());
            LocalTime endTime = LocalTime.parse(times[1].trim());
            
            List<LabPayment> bookedPayments = labPaymentRepository.findAll().stream()
                .filter(p -> p.getScheduledDateTime() != null && 
                             p.getScheduledDateTime().toLocalDate().isEqual(date) &&
                             p.getLabReferenceId() != null &&
                             p.getLabReferenceId().endsWith(testName) &&
                             !"CANCELLED".equalsIgnoreCase(p.getStatus()))
                .collect(Collectors.toList());
                
            List<Map<String, Object>> slots = new ArrayList<>();
            LocalTime current = startTime;
            
            while (current.isBefore(endTime) || current.equals(endTime)) {
                LocalDateTime slotDateTime = LocalDateTime.of(date, current);
                long bookedCount = bookedPayments.stream().filter(p -> p.getScheduledDateTime().equals(slotDateTime)).count();
                
                if (date.isEqual(LocalDate.now(ZoneId.of("Asia/Kolkata"))) && current.isBefore(LocalTime.now(ZoneId.of("Asia/Kolkata")))) {
                    current = current.plusMinutes(30);
                    continue;
                }
                
                Map<String, Object> slot = new HashMap<>();
                slot.put("time", current.toString());
                slot.put("bookedCount", bookedCount);
                slots.add(slot);
                
                current = current.plusMinutes(30);
            }
            
            response.put("success", true);
            response.put("slots", slots);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error calculating slots: " + e.getMessage());
        }
        return response;
    }

    @GetMapping("/api/lab-slot-details")
    @ResponseBody
    public Map<String, Object> getLabSlotDetails(@RequestParam String testName, @RequestParam String dateStr, @RequestParam String timeStr) {
        Map<String, Object> response = new HashMap<>();
        try {
            LocalDate date = LocalDate.parse(dateStr);
            LocalTime time = LocalTime.parse(timeStr);
            LocalDateTime targetDateTime = LocalDateTime.of(date, time);

            List<Map<String, String>> bookings = labPaymentRepository.findAll().stream()
                .filter(p -> p.getScheduledDateTime() != null &&
                             p.getScheduledDateTime().equals(targetDateTime) &&
                             p.getLabReferenceId() != null &&
                             p.getLabReferenceId().endsWith(testName) &&
                             !"CANCELLED".equalsIgnoreCase(p.getStatus()))
                .map(p -> {
                    Map<String, String> map = new HashMap<>();
                    map.put("patientName", p.getPatient() != null ? p.getPatient().getName() : "Unknown");
                    map.put("patientId", p.getPatient() != null ? p.getPatient().getUsername() : "N/A");
                    map.put("status", p.getStatus() != null ? p.getStatus() : "N/A");
                    map.put("tokenId", p.getTokenId() != null ? p.getTokenId() : "Pending");
                    return map;
                })
                .collect(Collectors.toList());

            response.put("success", true);
            response.put("bookings", bookings);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error fetching slot details: " + e.getMessage());
        }
        return response;
    }

    @GetMapping("/api/patient-search")
    @ResponseBody
    public List<Map<String, String>> searchPatients(@RequestParam String query) {
        List<User> patients = userRepository.searchPatients(query);
        List<Map<String, String>> results = new ArrayList<>();
        
        int limit = Math.min(patients.size(), 10);
        for (int i = 0; i < limit; i++) {
            User p = patients.get(i);
            Map<String, String> map = new HashMap<>();
            map.put("id", p.getUsername());
            map.put("name", p.getName());
            map.put("phone", p.getPhoneNumber());
            map.put("text", p.getUsername() + " - " + p.getName());
            results.add(map);
        }
        return results;
    }

    @PostMapping("/api/validate-tpin")
    @ResponseBody
    public Map<String, Object> validateTPinAjax(@RequestParam String tpin, HttpSession session) {
        Map<String, Object> response = new HashMap<>();
        User user = (User) session.getAttribute("loggedInUser");
        if (user != null) {
            User freshUser = userRepository.findById(user.getId()).orElse(null);
            if (freshUser != null && freshUser.gettPin() != null && freshUser.gettPin().equals(tpin)) {
                response.put("valid", true);
                return response;
            }
        }
        response.put("valid", false);
        return response;
    }

    @PostMapping("/api/generate-token")
    @ResponseBody
    public Map<String, Object> generateLabTokenAjax(
            @RequestParam Long paymentId,
            @RequestParam(required = false, defaultValue = "false") boolean regenerate) {
        
        Map<String, Object> response = new HashMap<>();
        try {
            LabPayment pmt = labPaymentRepository.findById(paymentId).orElse(null);
            if (pmt != null) {
                if (pmt.getTokenId() == null || regenerate) {
                    String newToken = generateTokenId(); 
                    pmt.setTokenId(newToken);
                    if (regenerate) {
                        pmt.setTransactionDate(LocalDateTime.now(ZoneId.of("Asia/Kolkata")));
                        pmt.setScheduledDateTime(LocalDateTime.now(ZoneId.of("Asia/Kolkata")));
                    } else if (pmt.getScheduledDateTime() == null) {
                        pmt.setScheduledDateTime(LocalDateTime.now(ZoneId.of("Asia/Kolkata")));
                    }
                    labPaymentRepository.save(pmt);
                    response.put("success", true);
                    response.put("tokenId", newToken);
                } else {
                    response.put("success", false);
                    response.put("message", "Token already exists.");
                }
            } else {
                response.put("success", false);
                response.put("message", "Payment not found.");
            }
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
        }
        return response;
    }

    @GetMapping("/billing")
    public String showBillingSearch(Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);
        session.removeAttribute("labBillingContext");
        
        List<HospitalDetails> hdList = hospitalDetailsRepository.findAll();
        if (!hdList.isEmpty()) {
            model.addAttribute("hospitalDetails", hdList.get(0));
        }
        
        return "lab/billing-search";
    }

    @PostMapping("/billing/step1")
    public String processBillingSearch(@RequestParam String patientId, HttpSession session, RedirectAttributes redirectAttributes) {
        User patient = userRepository.findByUsername(patientId);
        if (patient == null || !"Patient".equalsIgnoreCase(patient.getRole())) {
            redirectAttributes.addFlashAttribute("errorMessage", "Invalid Patient ID. User not found or is not a patient.");
            return "redirect:/lab/billing";
        }
        Map<String, Object> billingContext = new HashMap<>();
        billingContext.put("patientId", patient.getUsername());
        billingContext.put("patientName", patient.getName());
        session.setAttribute("labBillingContext", billingContext);
        return "redirect:/lab/billing/select";
    }

    @GetMapping("/billing/select")
    public String showBillingSelect(Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);

        @SuppressWarnings("unchecked")
        Map<String, Object> billingContext = (Map<String, Object>) session.getAttribute("labBillingContext");
        if (billingContext == null) return "redirect:/lab/billing";

        String patientId = (String) billingContext.get("patientId");
        model.addAttribute("patientId", patientId);
        model.addAttribute("patientName", billingContext.get("patientName"));

        List<LabService> allServices = labServiceRepository.findAllByOrderByServiceNameAsc();

        List<Map<String, Object>> pendingLabTests = new ArrayList<>();
        List<LabPayment> existingPayments = labPaymentRepository.findAll().stream()
            .filter(lp -> lp.getPatient() != null && patientId.equals(lp.getPatient().getUsername()))
            .collect(Collectors.toList());

        List<Appointment> patientAppointments = appointmentRepository.findAll().stream()
            .filter(a -> a.getPatient() != null && patientId.equals(a.getPatient().getUsername()))
            .collect(Collectors.toList());

        for (Appointment appt : patientAppointments) {
            if (appt.getPrescription() != null) {
                java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\[Lab Test Prescribed: (.*?)\\]").matcher(appt.getPrescription());
                while (m.find()) {
                    String testName = m.group(1).trim();
                    String refId = appt.getId() + "_" + testName;
                    
                    boolean alreadyPaid = existingPayments.stream().anyMatch(lp -> refId.equals(lp.getLabReferenceId()));
                    if (!alreadyPaid) {
                        double cost = 850.0;
                        for (LabService ls : allServices) {
                            if (ls.getServiceName().equalsIgnoreCase(testName)) {
                                cost = ls.getPrice() != null ? ls.getPrice() : 0.0;
                                break;
                            }
                        }
                        Map<String, Object> labInfo = new HashMap<>();
                        labInfo.put("id", refId); 
                        labInfo.put("name", testName);
                        labInfo.put("cost", cost);
                        labInfo.put("date", appt.getAppointmentDate() != null ? appt.getAppointmentDate().toString() : "N/A");
                        labInfo.put("doctorName", appt.getDoctor() != null ? appt.getDoctor().getName() : "Unknown");
                        labInfo.put("department", appt.getDepartment() != null ? appt.getDepartment() : "General");
                        
                        if (pendingLabTests.stream().noneMatch(l -> l.get("id").equals(refId))) {
                            pendingLabTests.add(labInfo);
                        }
                    }
                }
            }
        }
        model.addAttribute("pendingLabTests", pendingLabTests);
        
        List<HospitalDetails> hdList = hospitalDetailsRepository.findAll();
        if (!hdList.isEmpty()) {
            model.addAttribute("hospitalDetails", hdList.get(0));
        }

        return "lab/billing-select";
    }

    @PostMapping("/billing/step2")
    public String processLabSelection(@RequestParam(required = false) String[] selectedLabs, HttpSession session, RedirectAttributes redirectAttributes) {
        @SuppressWarnings("unchecked")
        Map<String, Object> billingContext = (Map<String, Object>) session.getAttribute("labBillingContext");
        if (billingContext == null) return "redirect:/lab/billing";

        List<String> labs = selectedLabs != null ? Arrays.asList(selectedLabs) : new ArrayList<>();
        if (labs.isEmpty()) {
            redirectAttributes.addFlashAttribute("errorMessage", "Please select at least one lab service to bill.");
            return "redirect:/lab/billing/select"; 
        }

        billingContext.put("selectedLabs", labs);
        session.setAttribute("labBillingContext", billingContext);
        
        return "redirect:/lab/billing/payment"; 
    }

    @GetMapping("/billing/payment")
    public String showBillingPayment(Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);

        @SuppressWarnings("unchecked")
        Map<String, Object> billingContext = (Map<String, Object>) session.getAttribute("labBillingContext");
        if (billingContext == null) return "redirect:/lab/billing";

        @SuppressWarnings("unchecked")
        List<String> labIds = (List<String>) billingContext.get("selectedLabs");

        double totalLabCost = 0;
        List<Map<String, Object>> labsToBill = new ArrayList<>();
        List<LabService> labServices = labServiceRepository.findAll();
        
        if (labIds != null) {
            for (String refId : labIds) {
                String testName = refId.contains("_") ? refId.substring(refId.indexOf('_') + 1) : refId;
                double cost = 850.0;
                for (LabService ls : labServices) {
                    if (ls.getServiceName().equalsIgnoreCase(testName) && ls.getPrice() != null) {
                        cost = ls.getPrice(); break;
                    }
                }
                totalLabCost += cost;
                
                Map<String, Object> labData = new HashMap<>();
                labData.put("id", refId);
                labData.put("name", testName);
                labData.put("cost", cost);
                labsToBill.add(labData);
            }
        }

        model.addAttribute("patientId", billingContext.get("patientId"));
        model.addAttribute("patientName", billingContext.get("patientName"));
        model.addAttribute("labsToBill", labsToBill);
        model.addAttribute("baseTotal", totalLabCost);
        
        List<HospitalDetails> hdList = hospitalDetailsRepository.findAll();
        if (!hdList.isEmpty()) {
            model.addAttribute("hospitalDetails", hdList.get(0));
        }

        return "lab/billing-payment";
    }

    @PostMapping("/billing/process")
    public String processLabPayment(
            @RequestParam Double baseAmount, @RequestParam Double cgst, @RequestParam Double sgst,
            @RequestParam Double discount, @RequestParam String paymentMode, @RequestParam String tpin,
            @RequestParam(required = false) String onlineMethod, @RequestParam(required = false) String transactionId,
            @RequestParam(required = false) String transactionDate,
            @RequestParam Map<String, String> allParams,
            HttpSession session, RedirectAttributes redirectAttributes) {
        
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        @SuppressWarnings("unchecked")
        Map<String, Object> billingContext = (Map<String, Object>) session.getAttribute("labBillingContext");
        if (billingContext == null) return "redirect:/lab/billing";

        try {
            User freshUser = userRepository.findById(loggedInUser.getId()).orElse(null);
            if (freshUser == null || freshUser.gettPin() == null || !freshUser.gettPin().equals(tpin)) {
                redirectAttributes.addFlashAttribute("errorMessage", "Security Validation Failed: Invalid T-Pin. Payment aborted.");
                return "redirect:/lab/billing/payment"; 
            }

            String patientId = (String) billingContext.get("patientId");
            User patient = userRepository.findByUsername(patientId);
            if (patient == null) throw new RuntimeException("Patient record missing.");
            
            LocalDateTime txnDate = null;
            if (transactionDate != null && !transactionDate.isEmpty()) {
                txnDate = LocalDateTime.parse(transactionDate);
            } else {
                txnDate = LocalDateTime.now(ZoneId.of("Asia/Kolkata"));
            }

            @SuppressWarnings("unchecked")
            List<String> labIds = (List<String>) billingContext.get("selectedLabs");
            List<Long> generatedLabPmtIds = new ArrayList<>();

            if (labIds != null && !labIds.isEmpty()) {
                double cgstSplit = (cgst != null ? cgst : 0) / labIds.size();
                double sgstSplit = (sgst != null ? sgst : 0) / labIds.size();
                double discSplit = (discount != null ? discount : 0) / labIds.size();
                
                String invTimeStr = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
                List<LabService> labServices = labServiceRepository.findAll();

                for (String labId : labIds) {
                    String testName = labId.contains("_") ? labId.substring(labId.indexOf('_') + 1) : labId;
                    double baseCost = 850.0;
                    for (LabService ls : labServices) {
                        if (ls.getServiceName().equalsIgnoreCase(testName) && ls.getPrice() != null) {
                            baseCost = ls.getPrice(); break;
                        }
                    }

                    LabPayment lPmt = new LabPayment();
                    lPmt.setLabReferenceId(labId);
                    lPmt.setPatient(patient);
                    lPmt.setBaseAmount(baseCost); 
                    lPmt.setCgst(cgstSplit); lPmt.setSgst(sgstSplit); lPmt.setDiscount(discSplit);
                    lPmt.setTotalAmount(baseCost + cgstSplit + sgstSplit - discSplit);
                    lPmt.setPaymentMode(paymentMode); lPmt.setOnlineMethod(onlineMethod);
                    lPmt.setTransactionId(transactionId); lPmt.setTransactionDate(txnDate);
                    lPmt.setRecordedBy(loggedInUser);
                    lPmt.setStatus("PENDING"); 
                    
                    // Assign Scheduled Date and Time only upon Payment Process
                    String sDateStr = allParams.get("scheduledDate_" + labId);
                    String sTimeStr = allParams.get("scheduledTime_" + labId);
                    if (sDateStr != null && !sDateStr.isEmpty() && sTimeStr != null && !sTimeStr.isEmpty()) {
                        LocalDateTime scheduledDT = LocalDateTime.of(LocalDate.parse(sDateStr), LocalTime.parse(sTimeStr));
                        lPmt.setScheduledDateTime(scheduledDT);
                    }
                    
                    LabPayment savedLabPmt = labPaymentRepository.save(lPmt);
                    savedLabPmt.setInvoiceNumber("INV-LAB-" + invTimeStr + "-" + String.format("%04d", savedLabPmt.getId()));
                    labPaymentRepository.save(savedLabPmt);
                    
                    generatedLabPmtIds.add(savedLabPmt.getId());
                }
            }

            session.removeAttribute("labBillingContext");
            return "redirect:/lab/billing/receipt?l=" + generatedLabPmtIds.stream().map(String::valueOf).collect(Collectors.joining(","));
            
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error: " + e.getMessage());
            return "redirect:/lab/billing/payment"; 
        }
    }

    @GetMapping("/billing/receipt")
    public String showLabReceipt(@RequestParam String l, Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);

        List<LabPayment> labPmts = new ArrayList<>();
        for (String idStr : l.split(",")) {
            labPaymentRepository.findById(Long.parseLong(idStr)).ifPresent(labPmts::add);
        }
        
        if (labPmts.isEmpty()) return "redirect:/lab/billing";
        
        double totalBase = 0, totalCgst = 0, totalSgst = 0, totalDiscount = 0, grandTotal = 0;
        User patient = labPmts.get(0).getPatient();
        LocalDateTime txnDate = labPmts.get(0).getTransactionDate();
        String pMode = labPmts.get(0).getPaymentMode();
        String pMethod = labPmts.get(0).getOnlineMethod();
        String txnId = labPmts.get(0).getTransactionId();
        String invoiceNumber = labPmts.get(0).getInvoiceNumber();
        
        Map<Long, String> cleanLabNames = new HashMap<>();
        for(LabPayment p : labPmts) {
            totalBase += p.getBaseAmount(); totalCgst += p.getCgst(); totalSgst += p.getSgst();
            totalDiscount += p.getDiscount(); grandTotal += p.getTotalAmount();
            
            String name = p.getLabReferenceId();
            if (name.contains("_")) {
                name = name.substring(name.indexOf('_') + 1);
            }
            cleanLabNames.put(p.getId(), name);
        }
        
        boolean hasActionableTokens = false;
        String todayStr = LocalDate.now(ZoneId.of("Asia/Kolkata")).toString();
        
        for (LabPayment p : labPmts) {
            String labStatus = p.getStatus() != null ? p.getStatus() : "";
            if ("COMPLETED".equalsIgnoreCase(labStatus) || "CLOSED".equalsIgnoreCase(labStatus) || "IN_PROGRESS".equalsIgnoreCase(labStatus)) {
                continue;
            }
            
            String labDateStr = p.getScheduledDateTime() != null ? 
                                p.getScheduledDateTime().toLocalDate().toString() : 
                                (p.getTransactionDate() != null ? p.getTransactionDate().toLocalDate().toString() : todayStr);

            if (p.getTokenId() == null || labDateStr.compareTo(todayStr) < 0) {
                hasActionableTokens = true; 
                break;
            }
        }
        
        model.addAttribute("hasActionableTokens", hasActionableTokens);
        model.addAttribute("patient", patient);
        model.addAttribute("txnDate", txnDate);
        model.addAttribute("pMode", pMode);
        model.addAttribute("pMethod", pMethod);
        model.addAttribute("txnId", txnId);
        model.addAttribute("invoiceNumber", invoiceNumber);
        model.addAttribute("labPmts", labPmts);
        model.addAttribute("cleanLabNames", cleanLabNames);
        model.addAttribute("totalBase", totalBase);
        model.addAttribute("totalCgst", totalCgst);
        model.addAttribute("totalSgst", totalSgst);
        model.addAttribute("totalDiscount", totalDiscount);
        model.addAttribute("grandTotal", grandTotal);
        
        List<HospitalDetails> hdList = hospitalDetailsRepository.findAll();
        if (!hdList.isEmpty()) {
            model.addAttribute("hospitalDetails", hdList.get(0));
        }
        
        return "lab/billing-receipt";
    }

    // ==========================================
    // 5. SAMPLE COLLECTION WORKFLOW
    // ==========================================
    @GetMapping("/sample-collection")
    public String sampleCollectionSearch(@RequestParam(required = false) String query, Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);

        if (query != null && !query.trim().isEmpty()) {
            String finalQuery = query.trim();
            
            List<LabPayment> pendingTests = labPaymentRepository.findAll().stream()
                .filter(p -> "PENDING".equalsIgnoreCase(p.getStatus()))
                .filter(p -> finalQuery.equalsIgnoreCase(p.getTokenId()) ||
                             (p.getPatient() != null && finalQuery.equalsIgnoreCase(p.getPatient().getUsername())))
                .collect(Collectors.toList());

            if (pendingTests.isEmpty()) {
                model.addAttribute("searchError", "No pending sample collection requests found for Token or Patient ID: " + finalQuery);
            } else {
                List<Appointment> allAppointments = appointmentRepository.findAll();
                List<Map<String, Object>> testDetailsList = new ArrayList<>();
                
                for (LabPayment pmt : pendingTests) {
                    Map<String, Object> map = new HashMap<>();
                    map.put("payment", pmt);
                    
                    String doctorName = "Self/Direct Walk-in";
                    String prescriptionText = "No specific prescription instructions attached.";
                    String testName = pmt.getLabReferenceId();
                    
                    if (testName != null && testName.contains("_")) {
                        String[] parts = testName.split("_", 2);
                        try {
                            Long apptId = Long.parseLong(parts[0]);
                            Appointment appt = allAppointments.stream().filter(a -> a.getId().equals(apptId)).findFirst().orElse(null);
                            if (appt != null) {
                                if (appt.getDoctor() != null) doctorName = "Dr. " + appt.getDoctor().getName();
                                if (appt.getPrescription() != null && !appt.getPrescription().isEmpty()) {
                                    prescriptionText = appt.getPrescription();
                                }
                            }
                        } catch (Exception e) {}
                        testName = parts[1];
                    }
                    map.put("testName", testName);
                    map.put("doctorName", doctorName);
                    map.put("prescription", prescriptionText);
                    testDetailsList.add(map);
                }
                model.addAttribute("testDetailsList", testDetailsList);
            }
            model.addAttribute("query", finalQuery);
        }
        return "lab/sample-collection";
    }

    @PostMapping("/sample-collection/confirm")
    @ResponseBody
    public Map<String, Object> confirmSampleCollection(@RequestBody Map<String, String> payload, HttpSession session) {
        Map<String, Object> response = new HashMap<>();
        if (!isLoggedIn(session)) {
            response.put("success", false);
            response.put("message", "Session expired. Please log in.");
            return response;
        }
        try {
            Long paymentId = Long.parseLong(payload.get("paymentId"));
            LabPayment pmt = labPaymentRepository.findById(paymentId)
                    .orElseThrow(() -> new RuntimeException("Test record not found"));
            
            pmt.setStatus("IN_PROGRESS");
            pmt.setSampleCollectedDate(LocalDateTime.now(ZoneId.of("Asia/Kolkata")));
            
            try {
                if(payload.containsKey("batchId")) pmt.setBatchId(payload.get("batchId"));
                if(payload.containsKey("method")) pmt.setCollectionMethod(payload.get("method"));
                if(payload.containsKey("takerName")) pmt.setSampleTakerName(payload.get("takerName"));
                if(payload.containsKey("sampleId")) pmt.setSampleId(payload.get("sampleId"));
            } catch (Exception ignored) {}

            labPaymentRepository.save(pmt);
            
            response.put("success", true);
            response.put("message", "Sample collected and processed successfully!");
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
        }
        return response;
    }

    // ==========================================
    // 5.5 PROCESS COLLECTED SAMPLES WORKFLOW
    // ==========================================
    @GetMapping("/process-samples")
    public String processSamplesList(@RequestParam(required = false) String testName, Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);

        model.addAttribute("services", labServiceRepository.findAllByOrderByServiceNameAsc());

        if (testName != null && !testName.isEmpty()) {
            List<LabPayment> inProgressSamples = labPaymentRepository.findAll().stream()
                .filter(p -> "IN_PROGRESS".equalsIgnoreCase(p.getStatus()))
                .filter(p -> p.getLabReferenceId() != null && p.getLabReferenceId().endsWith(testName))
                .collect(Collectors.toList());
            
            Map<Long, String> cleanNames = new HashMap<>();
            for (LabPayment p : inProgressSamples) {
                String name = p.getLabReferenceId();
                if (name.contains("_")) name = name.substring(name.indexOf('_') + 1);
                cleanNames.put(p.getId(), name);
            }
            
            model.addAttribute("samples", inProgressSamples);
            model.addAttribute("cleanNames", cleanNames);
            model.addAttribute("selectedTest", testName);
        }

        return "lab/process-samples";
    }

    @GetMapping("/process-samples/details/{id}")
    public String processSampleDetails(@PathVariable Long id, Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);

        LabPayment pmt = labPaymentRepository.findById(id).orElse(null);
        if(pmt == null || !"IN_PROGRESS".equalsIgnoreCase(pmt.getStatus())) {
            return "redirect:/lab/process-samples";
        }

        String doctorName = "Self/Direct Walk-in";
        Long apptIdForModal = null;
        String testName = pmt.getLabReferenceId();

        if (testName != null && testName.contains("_")) {
            String[] parts = testName.split("_", 2);
            try {
                Long apptId = Long.parseLong(parts[0]);
                apptIdForModal = apptId;
                Appointment appt = appointmentRepository.findById(apptId).orElse(null);
                if (appt != null && appt.getDoctor() != null) {
                    doctorName = "Dr. " + appt.getDoctor().getName();
                }
            } catch (Exception e) {}
            testName = parts[1];
        }

        model.addAttribute("payment", pmt);
        model.addAttribute("testName", testName);
        model.addAttribute("doctorName", doctorName);
        model.addAttribute("apptId", apptIdForModal);

        return "lab/process-sample-details";
    }

    // ==========================================
    // 6. REPORT CONFIGURATION
    // ==========================================
    @GetMapping("/report-config")
    public String listReportConfigs(Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);
        model.addAttribute("services", labServiceRepository.findAllByOrderByServiceNameAsc());
        return "lab/report-config-list";
    }

    @GetMapping("/report-config/{id}")
    public String editReportConfig(@PathVariable Long id, Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);
        
        LabService service = labServiceRepository.findById(id).orElse(null);
        if (service == null) return "redirect:/lab/report-config";
        
        model.addAttribute("service", service);
        return "lab/report-config-edit";
    }

    @PostMapping("/report-config/{id}/save")
    @ResponseBody
    public Map<String, Object> saveReportConfig(@PathVariable Long id, @RequestBody Map<String, String> payload, HttpSession session) {
        Map<String, Object> response = new HashMap<>();
        if (!isLoggedIn(session)) {
            response.put("success", false);
            response.put("message", "Session expired. Please log in.");
            return response;
        }
        try {
            LabService service = labServiceRepository.findById(id)
                    .orElseThrow(() -> new RuntimeException("Service not found"));
            
            service.setReportTemplateConfig(payload.get("templateConfig"));
            labServiceRepository.save(service);
            
            response.put("success", true);
            response.put("message", "Template configuration saved successfully.");
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
        }
        return response;
    }

    // ==========================================
    // 7. GENERATE REPORT (Updated JSON Parsing)
    // ==========================================
    @GetMapping("/generate-report")
    public String generateReportSearch(@RequestParam(required = false) String query, Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);

        if (query != null && !query.trim().isEmpty()) {
            String finalQuery = query.trim();
            
            List<LabPayment> inProgressTests = labPaymentRepository.findAll().stream()
                .filter(p -> "IN_PROGRESS".equalsIgnoreCase(p.getStatus()))
                .filter(p -> finalQuery.equalsIgnoreCase(p.getTokenId()) ||
                             (p.getPatient() != null && finalQuery.equalsIgnoreCase(p.getPatient().getUsername())))
                .collect(Collectors.toList());

            if (inProgressTests.isEmpty()) {
                model.addAttribute("searchError", "No 'In Progress' sample requests found for Token or Patient ID: " + finalQuery);
            } else {
                List<Appointment> allAppointments = appointmentRepository.findAll();
                List<LabService> allServices = labServiceRepository.findAll();
                List<Map<String, Object>> testDetailsList = new ArrayList<>();
                
                for (LabPayment pmt : inProgressTests) {
                    Map<String, Object> map = new HashMap<>();
                    map.put("payment", pmt);
                    
                    String doctorName = "Self/Direct Walk-in";
                    String prescriptionText = "No specific prescription instructions attached.";
                    String testName = pmt.getLabReferenceId();
                    String templateConfigStr = null;
                    
                    if (testName != null && testName.contains("_")) {
                        String[] parts = testName.split("_", 2);
                        try {
                            Long apptId = Long.parseLong(parts[0]);
                            Appointment appt = allAppointments.stream().filter(a -> a.getId().equals(apptId)).findFirst().orElse(null);
                            if (appt != null) {
                                if (appt.getDoctor() != null) doctorName = "Dr. " + appt.getDoctor().getName();
                                if (appt.getPrescription() != null && !appt.getPrescription().isEmpty()) {
                                    prescriptionText = appt.getPrescription();
                                }
                            }
                        } catch (Exception e) {}
                        testName = parts[1];
                    }

                    for (LabService ls : allServices) {
                        if (ls.getServiceName().equalsIgnoreCase(testName)) {
                            templateConfigStr = ls.getReportTemplateConfig();
                            break;
                        }
                    }

                    // JSON Parsing for Thymeleaf Render
                    List<Map<String, Object>> parsedReportConfig = null;
                    if (templateConfigStr != null && !templateConfigStr.trim().isEmpty() && !templateConfigStr.equals("{}") && !templateConfigStr.equals("[]")) {
                        try {
                            ObjectMapper mapper = new ObjectMapper();
                            parsedReportConfig = mapper.readValue(templateConfigStr, new TypeReference<List<Map<String, Object>>>() {});
                        } catch (Exception e) {
                            System.err.println("Failed to parse report template config: " + e.getMessage());
                        }
                    }

                    map.put("testName", testName);
                    map.put("doctorName", doctorName);
                    map.put("prescription", prescriptionText);
                    map.put("reportConfig", parsedReportConfig); // Send the parsed List of Maps
                    testDetailsList.add(map);
                }
                model.addAttribute("testDetailsList", testDetailsList);
            }
            model.addAttribute("query", finalQuery);
        }
        return "lab/generate-report";
    }

    @PostMapping("/generate-report/submit")
    @ResponseBody
    public Map<String, Object> submitGenerateReport(@RequestBody Map<String, String> payload, HttpSession session) {
        Map<String, Object> response = new HashMap<>();
        if (!isLoggedIn(session)) {
            response.put("success", false);
            response.put("message", "Session expired. Please log in.");
            return response;
        }
        try {
            Long paymentId = Long.parseLong(payload.get("paymentId"));
            String reportDataJson = payload.get("reportData");
            
            LabPayment pmt = labPaymentRepository.findById(paymentId)
                    .orElseThrow(() -> new RuntimeException("Test record not found"));
            
            pmt.setStatus("CLOSED");

            try {
                pmt.setReportData(reportDataJson);
            } catch (Exception ignored) {}
            
            labPaymentRepository.save(pmt);
            
            response.put("success", true);
            response.put("message", "Lab Report successfully generated and published!");
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
        }
        return response;
    }

    // ==========================================
    // 8. PROFILE MANAGEMENT
    // ==========================================
    @GetMapping("/profile")
    public String viewProfile(Model model, HttpSession session) {
        if (!isLoggedIn(session)) return "redirect:/login";
        addUserAttributes(model, session);
        
        User user = (User) session.getAttribute("loggedInUser");
        User freshUser = userRepository.findById(user.getId()).orElse(user);
        model.addAttribute("userDetails", freshUser);
        
        List<HospitalDetails> hdList = hospitalDetailsRepository.findAll();
        if (!hdList.isEmpty()) {
            model.addAttribute("hospitalDetails", hdList.get(0));
        }
        
        return "lab/profile";
    }

    @PostMapping("/profile/tpin")
    public String updateTPin(@RequestParam("tpin") String tpin, 
                             @RequestParam("confirmTpin") String confirmTpin, 
                             HttpSession session, RedirectAttributes redirectAttributes) {
        if (!isLoggedIn(session)) return "redirect:/login";
        User user = (User) session.getAttribute("loggedInUser");
        
        if (!tpin.equals(confirmTpin)) {
            redirectAttributes.addFlashAttribute("errorMessage", "T-Pins do not match. Please try again.");
            return "redirect:/lab/profile"; 
        }
        
        try {
            User freshUser = userRepository.findById(user.getId()).orElse(null);
            if(freshUser != null) {
                freshUser.settPin(tpin);
                userRepository.save(freshUser);
                redirectAttributes.addFlashAttribute("successMessage", "T-Pin saved successfully! You can now use it to secure Lab Billings.");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error updating T-Pin: " + e.getMessage());
        }
        return "redirect:/lab/profile"; 
    }

    @PostMapping("/profile/password")
    public String updatePassword(@RequestParam("newPassword") String newPassword, 
                                 @RequestParam("confirmPassword") String confirmPassword, 
                                 HttpSession session, RedirectAttributes redirectAttributes) {
        if (!isLoggedIn(session)) return "redirect:/login";
        User user = (User) session.getAttribute("loggedInUser");
        
        if (!newPassword.equals(confirmPassword)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Passwords do not match. Please try again.");
            return "redirect:/lab/profile"; 
        }
        
        try {
            boolean updated = userService.updatePassword(user.getId(), newPassword);
            if (updated) {
                user.setPassword(newPassword); 
                redirectAttributes.addFlashAttribute("successMessage", "Account password updated successfully!");
            } else {
                redirectAttributes.addFlashAttribute("errorMessage", "Failed to update password.");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "An error occurred while updating the password.");
        }
        return "redirect:/lab/profile"; 
    }
}