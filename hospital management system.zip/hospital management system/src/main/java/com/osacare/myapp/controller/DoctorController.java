package com.osacare.myapp.controller;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Period;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.osacare.myapp.entity.Appointment;
import com.osacare.myapp.entity.DoctorProfile;
import com.osacare.myapp.entity.LabService;
import com.osacare.myapp.entity.PatientProfile;
import com.osacare.myapp.entity.Prescription;
import com.osacare.myapp.entity.User;
import com.osacare.myapp.entity.VitalSign;
import com.osacare.myapp.repository.AppointmentRepository;
import com.osacare.myapp.repository.DoctorProfileRepository;
import com.osacare.myapp.repository.LabServiceRepository;
import com.osacare.myapp.repository.PatientProfileRepository;
import com.osacare.myapp.repository.VitalSignRepository;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/doctor")
public class DoctorController {

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Autowired
    private PatientProfileRepository patientProfileRepository;
    
    @Autowired
    private DoctorProfileRepository doctorProfileRepository;

    @Autowired
    private VitalSignRepository vitalSignRepository;

    @Autowired
    private LabServiceRepository labServiceRepository;

    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        if (loggedInUser == null || !"doctor".equalsIgnoreCase(loggedInUser.getRole())) {
            return "redirect:/login";
        }
        
        model.addAttribute("name", loggedInUser.getName());
        model.addAttribute("username", loggedInUser.getUsername());
        model.addAttribute("role", loggedInUser.getRole());
        
        return "doctor/dashboard";
    }

    @GetMapping("/appointments")
    public String myAppointments(@RequestParam(required = false) LocalDate date, HttpSession session, Model model) {
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        if (loggedInUser == null || !"doctor".equalsIgnoreCase(loggedInUser.getRole())) {
            return "redirect:/login";
        }

        LocalDate filterDate = (date != null) ? date : LocalDate.now(ZoneId.of("Asia/Kolkata"));
        List<Appointment> appointments = appointmentRepository.findByDoctorAndAppointmentDateOrderByAppointmentTimeAsc(loggedInUser, filterDate);

        LocalDate today = LocalDate.now(ZoneId.of("Asia/Kolkata"));

        // Active: Token is generated AND appointment is not expired (today or future) AND not cancelled/completed/closed
        List<Appointment> activeAppointments = appointments.stream()
                .filter(a -> a.getTokenId() != null && !a.getAppointmentDate().isBefore(today) 
                        && !"CANCELLED".equals(a.getStatus())
                        && !"COMPLETED".equals(a.getStatus())
                        && !"CLOSED".equals(a.getStatus()))
                .collect(Collectors.toList());

        // Completed: Status is COMPLETED or CLOSED
        List<Appointment> completedAppointments = appointments.stream()
                .filter(a -> "COMPLETED".equals(a.getStatus()) || "CLOSED".equals(a.getStatus()))
                .collect(Collectors.toList());

        // Inactive: Token not generated OR appointment is expired (past dates) OR cancelled
        List<Appointment> inactiveAppointments = appointments.stream()
                .filter(a -> (a.getTokenId() == null || a.getAppointmentDate().isBefore(today) || "CANCELLED".equals(a.getStatus()))
                        && !"COMPLETED".equals(a.getStatus())
                        && !"CLOSED".equals(a.getStatus()))
                .collect(Collectors.toList());

        // Fetch patient profiles for these appointments to prevent Thymeleaf NullPointerException
        Map<Long, PatientProfile> patientProfiles = new HashMap<>();
        for (Appointment appt : appointments) {
            if (appt.getPatient() != null && !patientProfiles.containsKey(appt.getPatient().getId())) {
                PatientProfile pp = patientProfileRepository.findByUser(appt.getPatient());
                if (pp != null) {
                    patientProfiles.put(appt.getPatient().getId(), pp);
                }
            }
        }

        // Fetch all appointments for this doctor to populate the calendar counts
        List<Appointment> allDoctorAppts = appointmentRepository.findAll().stream()
                .filter(a -> a.getDoctor() != null && a.getDoctor().getId().equals(loggedInUser.getId()) && a.getAppointmentDate() != null)
                .collect(Collectors.toList());

        Map<String, Long> appointmentCounts = allDoctorAppts.stream()
                .collect(Collectors.groupingBy(
                        a -> a.getAppointmentDate().toString(),
                        Collectors.counting()
                ));

        model.addAttribute("activeAppointments", activeAppointments);
        model.addAttribute("inactiveAppointments", inactiveAppointments);
        model.addAttribute("completedAppointments", completedAppointments); 
        model.addAttribute("appointmentCounts", appointmentCounts);
        model.addAttribute("patientProfiles", patientProfiles); 
        model.addAttribute("filterDate", filterDate.toString());
        model.addAttribute("today", today.toString());
        
        // Ensure sidebar has details as well
        model.addAttribute("name", loggedInUser.getName());
        model.addAttribute("username", loggedInUser.getUsername());
        model.addAttribute("role", loggedInUser.getRole());
        
        return "doctor/appointments";
    }

    @GetMapping("/appointment/{id}")
    public String viewAppointment(@PathVariable Long id, HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        if (loggedInUser == null || !"doctor".equalsIgnoreCase(loggedInUser.getRole())) {
            return "redirect:/login";
        }

        Appointment appointment = appointmentRepository.findById(id).orElse(null);
        if (appointment == null || !appointment.getDoctor().getId().equals(loggedInUser.getId())) {
            redirectAttributes.addFlashAttribute("errorMessage", "Appointment not found or access denied.");
            return "redirect:/doctor/appointments";
        }

        PatientProfile patientProfile = patientProfileRepository.findByUser(appointment.getPatient());
        
        String patientAge = "N/A";
        if (patientProfile != null) {
            if (patientProfile.getDateOfBirth() != null) {
                Period age = Period.between(patientProfile.getDateOfBirth(), LocalDate.now(ZoneId.of("Asia/Kolkata")));
                patientAge = age.getYears() + "Y-" + age.getMonths() + "M-" + age.getDays() + "D";
            } else if (patientProfile.getBirthYear() != null) {
                patientAge = (LocalDate.now(ZoneId.of("Asia/Kolkata")).getYear() - patientProfile.getBirthYear()) + " Years";
            }
        }

        VitalSign vitals = vitalSignRepository.findByAppointmentId(id);

        List<Appointment> previousAppointments = appointmentRepository.findByPatientOrderByAppointmentDateDesc(appointment.getPatient())
                .stream()
                .filter(a -> !a.getId().equals(id))
                .filter(a -> "COMPLETED".equalsIgnoreCase(a.getStatus()) || "CLOSED".equalsIgnoreCase(a.getStatus()))
                .collect(Collectors.toList());

        List<Appointment> upcomingAppointments = appointmentRepository.findByPatientOrderByAppointmentDateDesc(appointment.getPatient())
                .stream()
                .filter(a -> !a.getId().equals(id))
                .filter(a -> !"COMPLETED".equalsIgnoreCase(a.getStatus()) && !"CLOSED".equalsIgnoreCase(a.getStatus()))
                .collect(Collectors.toList());

        boolean isTokenExpired = false;
        if (appointment.getAppointmentDate() != null) {
            isTokenExpired = appointment.getAppointmentDate().isBefore(LocalDate.now(ZoneId.of("Asia/Kolkata")));
        }

        // Allow editing even if status is COMPLETED, disable only if CLOSED completely
        boolean isReadOnly = isTokenExpired 
                             || appointment.getTokenId() == null 
                             || "CLOSED".equalsIgnoreCase(appointment.getStatus());

        List<LabService> labServices = labServiceRepository.findAll().stream()
                .filter(LabService::isActive)
                .collect(Collectors.toList());

        model.addAttribute("appointment", appointment);
        model.addAttribute("patientProfile", patientProfile);
        model.addAttribute("patientAge", patientAge);
        model.addAttribute("vitals", vitals);
        model.addAttribute("previousAppointments", previousAppointments);
        model.addAttribute("upcomingAppointments", upcomingAppointments);
        model.addAttribute("patientLabTests", Collections.emptyList()); 
        model.addAttribute("isTokenExpired", isTokenExpired);
        model.addAttribute("isReadOnly", isReadOnly);
        model.addAttribute("labServices", labServices);

        return "doctor/view-appointment";
    }

    @GetMapping("/appointment/{id}/print-view")
    public String viewPrescriptionPrint(@PathVariable Long id, HttpSession session, Model model) {
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        if (loggedInUser == null || !"doctor".equalsIgnoreCase(loggedInUser.getRole())) {
            return "redirect:/login";
        }

        Appointment appointment = appointmentRepository.findById(id).orElse(null);
        if (appointment == null) {
            return "redirect:/doctor/dashboard";
        }

        PatientProfile patientProfile = patientProfileRepository.findByUser(appointment.getPatient());
        String patientAge = "N/A";
        if (patientProfile != null) {
            if (patientProfile.getDateOfBirth() != null) {
                Period age = Period.between(patientProfile.getDateOfBirth(), LocalDate.now(ZoneId.of("Asia/Kolkata")));
                patientAge = age.getYears() + "Y-" + age.getMonths() + "M-" + age.getDays() + "D";
            } else if (patientProfile.getBirthYear() != null) {
                patientAge = (LocalDate.now(ZoneId.of("Asia/Kolkata")).getYear() - patientProfile.getBirthYear()) + " Years";
            }
        }
        
        VitalSign vitals = vitalSignRepository.findByAppointmentId(id);
        
        model.addAttribute("appointment", appointment);
        model.addAttribute("vitals", vitals);
        model.addAttribute("patientAge", patientAge);
        model.addAttribute("isPreview", true); 
        
        return "receptionist/prescription-print-view";
    }

    @PostMapping("/appointment/save-prescription")
    public String savePrescription(
            @RequestParam Long appointmentId, 
            @RequestParam(required = false) String chiefComplaints,
            @RequestParam(required = false) String prescription, 
            @RequestParam(required = false, defaultValue = "false") boolean isFreeFollowUp,
            HttpSession session, 
            RedirectAttributes redirectAttributes) {
        
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        if (loggedInUser == null || !"doctor".equalsIgnoreCase(loggedInUser.getRole())) {
            return "redirect:/login";
        }

        Appointment appointment = appointmentRepository.findById(appointmentId).orElse(null);
        
        if (appointment != null && appointment.getDoctor().getId().equals(loggedInUser.getId())) {
            
            boolean isTokenExpired = appointment.getAppointmentDate() != null && appointment.getAppointmentDate().isBefore(LocalDate.now(ZoneId.of("Asia/Kolkata")));
            boolean isClosed = "CLOSED".equalsIgnoreCase(appointment.getStatus());
            boolean noToken = appointment.getTokenId() == null;
            
            if (isTokenExpired) {
                redirectAttributes.addFlashAttribute("errorMessage", "Cannot save data. Token has expired and was not regenerated.");
            } else if (noToken) {
                redirectAttributes.addFlashAttribute("errorMessage", "Cannot save data. Token is not generated yet.");
            } else if (isClosed) {
                redirectAttributes.addFlashAttribute("errorMessage", "Cannot save data. Appointment is already closed by reception.");
            } else {
                
                if (chiefComplaints != null || prescription != null) {
                    Prescription pres = appointment.getPrescriptionRecord();
                    if (pres == null) {
                        pres = new Prescription();
                        pres.setAppointment(appointment);
                        appointment.setPrescriptionRecord(pres);
                    }
                    
                    if (chiefComplaints != null) pres.setChiefComplaints(chiefComplaints);
                    if (prescription != null) pres.setPrescriptionText(prescription);
                }
                
                if (prescription != null) {
                    java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\[Next Appointment: (.*?) at (.*?)(?: - FREE)?\\]").matcher(prescription);
                    if (m.find()) {
                        String dateStr = m.group(1).trim();
                        String timeStr = m.group(2).trim();
                        
                        boolean exists = appointmentRepository.findAll().stream()
                            .anyMatch(a -> a.getPatient().getId().equals(appointment.getPatient().getId()) &&
                                           a.getDoctor().getId().equals(appointment.getDoctor().getId()) &&
                                           a.getAppointmentDate() != null && a.getAppointmentDate().toString().equals(dateStr) &&
                                           a.getAppointmentTime() != null && a.getAppointmentTime().equals(timeStr) &&
                                           !"CANCELLED".equals(a.getStatus()));
                                           
                        if (!exists) {
                            Appointment nextAppt = new Appointment();
                            nextAppt.setPatient(appointment.getPatient());
                            nextAppt.setDoctor(appointment.getDoctor());
                            nextAppt.setDepartment(appointment.getDepartment());
                            try {
                                nextAppt.setAppointmentDate(LocalDate.parse(dateStr));
                                nextAppt.setAppointmentTime(timeStr);
                                nextAppt.setReason(isFreeFollowUp ? "Free Follow up" : "Follow up");
                                nextAppt.setStatus("SCHEDULED");
                                nextAppt.setPaymentStatus("PENDING");
                                appointmentRepository.save(nextAppt);
                            } catch (Exception e) {
                            }
                        }
                    }
                }
                
                appointment.setStatus("COMPLETED");
                appointmentRepository.save(appointment); 
                
                redirectAttributes.addFlashAttribute("successMessage", "Medical data saved successfully. Patient moved to Reception/Billing queue.");
            }
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to save details. Access denied.");
        }

        return "redirect:/doctor/appointment/" + appointmentId;
    }

    @PostMapping("/appointments/update-status")
    public String updateAppointmentStatus(
            @RequestParam Long appointmentId, 
            @RequestParam String status, 
            @RequestParam(required = false) LocalDate filterDate, 
            HttpSession session, 
            RedirectAttributes redirectAttributes) {
            
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        if (loggedInUser == null || !"doctor".equalsIgnoreCase(loggedInUser.getRole())) {
            return "redirect:/login";
        }

        Appointment appointment = appointmentRepository.findById(appointmentId).orElse(null);
        
        if (appointment != null && appointment.getDoctor().getId().equals(loggedInUser.getId())) {
            appointment.setStatus(status);
            appointmentRepository.save(appointment);
            redirectAttributes.addFlashAttribute("successMessage", "Appointment status updated to " + status + ".");
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "Invalid request or permission denied.");
        }

        String redirectUrl = "redirect:/doctor/appointments";
        if (filterDate != null) {
            redirectUrl += "?date=" + filterDate;
        }
        return redirectUrl;
    }

    @GetMapping("/api/doctor-slots")
    @ResponseBody
    public List<Map<String, Object>> getDoctorSlots(@RequestParam Long doctorId, @RequestParam String date) {
        List<Map<String, Object>> availableSlots = new ArrayList<>();
        
        try {
            LocalDate selectedDate = LocalDate.parse(date);
            ZoneId istZone = ZoneId.of("Asia/Kolkata");
            LocalDate today = LocalDate.now(istZone);

            if (selectedDate.isBefore(today)) {
                return availableSlots; 
            }

            DoctorProfile doctorProfile = doctorProfileRepository.findById(doctorId).orElse(null);
            if (doctorProfile == null) return availableSlots;

            LocalTime startTime = null;
            LocalTime endTime = null;

            String timings = doctorProfile.getAvailabilityTimings();
            String dayOfWeekShort = selectedDate.getDayOfWeek().getDisplayName(TextStyle.SHORT, Locale.ENGLISH);

            if (timings != null && !timings.trim().isEmpty() && !"Not Specified".equalsIgnoreCase(timings.trim())) {
                try {
                    if (timings.contains("|") || timings.matches(".*[A-Za-z]{3}:.*")) {
                        String[] dayParts = timings.split("\\|");
                        for (String dayPart : dayParts) {
                            if (dayPart.trim().startsWith(dayOfWeekShort)) {
                                String timeRange = dayPart.substring(dayPart.indexOf(":") + 1).trim();
                                String[] bounds = timeRange.split("-");
                                if (bounds.length >= 2) {
                                    startTime = parseRobustTime(bounds[0]);
                                    endTime = parseRobustTime(bounds[1]);
                                }
                                break;
                            }
                        }
                    } else {
                        String[] parts = timings.split("(?i)\\s*-\\s*|\\s+to\\s+");
                        if (parts.length >= 2) {
                            startTime = parseRobustTime(parts[0]);
                            endTime = parseRobustTime(parts[1]);
                        }
                    }
                } catch (Exception e) {
                    System.err.println("Warning: Failed to parse timings '" + timings + "' for Doctor ID: " + doctorId + " -> " + e.getMessage());
                }
            }

            if (startTime == null || endTime == null) {
                return availableSlots;
            }

            LocalTime currentTime = startTime;
            LocalTime now = LocalTime.now(istZone);
            DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("hh:mm a");

            while (currentTime.isBefore(endTime)) {
                if (selectedDate.isEqual(today) && currentTime.isBefore(now)) {
                    currentTime = currentTime.plusMinutes(30);
                    continue;
                }

                String timeString = currentTime.format(timeFormatter);
                long bookedCount = appointmentRepository.countByDoctorAndAppointmentDateAndAppointmentTimeAndStatusNot(
                    doctorProfile.getUser(), selectedDate, timeString, "CANCELLED"
                );

                Map<String, Object> slotData = new HashMap<>();
                slotData.put("timeValue", timeString);
                slotData.put("displayLabel", timeString + " (" + bookedCount + " booked)");
                
                availableSlots.add(slotData);

                currentTime = currentTime.plusMinutes(30);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return availableSlots;
    }

    private LocalTime parseRobustTime(String timeStr) {
        timeStr = timeStr.trim().toUpperCase().replaceAll("\\s+", "");
        try {
            if (timeStr.contains("AM") || timeStr.contains("PM")) {
                if (!timeStr.contains(":")) {
                    timeStr = timeStr.replace("AM", ":00AM").replace("PM", ":00PM");
                }
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("h:mma");
                return LocalTime.parse(timeStr, formatter);
            } else {
                if (!timeStr.contains(":")) {
                    timeStr += ":00";
                }
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("H:mm");
                return LocalTime.parse(timeStr, formatter);
            }
        } catch (Exception e) {
            throw new RuntimeException("Unparseable fragment: " + timeStr);
        }
    }

    @PostMapping("/appointment/cancel-followup")
    public String cancelFollowUp(
            @RequestParam Long targetApptId, 
            @RequestParam Long currentApptId, 
            HttpSession session, 
            RedirectAttributes redirectAttributes) {
        
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        if (loggedInUser == null || !"doctor".equalsIgnoreCase(loggedInUser.getRole())) return "redirect:/login";

        Appointment target = appointmentRepository.findById(targetApptId).orElse(null);
        if (target != null && target.getDoctor().getId().equals(loggedInUser.getId())) {
            
            if (!"PENDING".equalsIgnoreCase(target.getPaymentStatus())) {
                redirectAttributes.addFlashAttribute("errorMessage", "Cannot cancel follow-up because payment is already completed.");
                return "redirect:/doctor/appointment/" + currentApptId;
            }
            
            target.setStatus("CANCELLED");
            appointmentRepository.save(target);
            
            Appointment current = appointmentRepository.findById(currentApptId).orElse(null);
            if (current != null && current.getPrescription() != null) {
                String updatedRx = current.getPrescription().replaceAll("\\[Next Appointment:.*?\\]", "");
                Prescription p = current.getPrescriptionRecord();
                if (p != null) {
                    p.setPrescriptionText(updatedRx);
                    appointmentRepository.save(current);
                }
            }
            redirectAttributes.addFlashAttribute("successMessage", "Follow-up appointment cancelled successfully.");
        }
        return "redirect:/doctor/appointment/" + currentApptId;
    }

    @PostMapping("/appointment/reschedule-followup")
    public String rescheduleFollowUp(
            @RequestParam Long targetApptId, 
            @RequestParam Long currentApptId, 
            @RequestParam String newDate, 
            @RequestParam String newTime, 
            HttpSession session, 
            RedirectAttributes redirectAttributes) {
        
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        if (loggedInUser == null || !"doctor".equalsIgnoreCase(loggedInUser.getRole())) return "redirect:/login";

        Appointment target = appointmentRepository.findById(targetApptId).orElse(null);
        if (target != null && target.getDoctor().getId().equals(loggedInUser.getId())) {
            
            if (!"PENDING".equalsIgnoreCase(target.getPaymentStatus())) {
                redirectAttributes.addFlashAttribute("errorMessage", "Cannot reschedule follow-up because payment is already completed.");
                return "redirect:/doctor/appointment/" + currentApptId;
            }

            try {
                target.setAppointmentDate(LocalDate.parse(newDate));
                target.setAppointmentTime(newTime);
                appointmentRepository.save(target);

                Appointment current = appointmentRepository.findById(currentApptId).orElse(null);
                if (current != null && current.getPrescription() != null) {
                    String updatedRx = current.getPrescription().replaceAll(
                        "\\[Next Appointment:.*?\\]", 
                        "[Next Appointment: " + newDate + " at " + newTime + "]"
                    );
                    Prescription p = current.getPrescriptionRecord();
                    if (p != null) {
                        p.setPrescriptionText(updatedRx);
                        appointmentRepository.save(current);
                    }
                }
                redirectAttributes.addFlashAttribute("successMessage", "Follow-up appointment rescheduled successfully.");
            } catch (Exception e) {
                redirectAttributes.addFlashAttribute("errorMessage", "Invalid date/time format provided.");
            }
        }
        return "redirect:/doctor/appointment/" + currentApptId;
    }
}