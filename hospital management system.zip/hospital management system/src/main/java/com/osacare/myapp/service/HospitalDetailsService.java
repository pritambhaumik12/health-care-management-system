package com.osacare.myapp.service;

import org.springframework.stereotype.Service;

import com.osacare.myapp.entity.HospitalDetails;
import com.osacare.myapp.repository.HospitalDetailsRepository;

@Service
public class HospitalDetailsService {

    private final HospitalDetailsRepository hospitalDetailsRepository;

    public HospitalDetailsService(HospitalDetailsRepository hospitalDetailsRepository) {
        this.hospitalDetailsRepository = hospitalDetailsRepository;
    }

    // Fetch the single hospital details record, or return a new empty one if none exists
    public HospitalDetails getDetails() {
        return hospitalDetailsRepository.findAll().stream().findFirst().orElse(new HospitalDetails());
    }

    // Save or update the details
    public void saveDetails(HospitalDetails details) {
        HospitalDetails existingDetails = getDetails();
        
        // If an entry already exists, ensure we are updating it instead of creating a new row
        if (existingDetails.getId() != null) {
            details.setId(existingDetails.getId());
        }
        
        hospitalDetailsRepository.save(details);
    }
}