package com.osacare.myapp.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.osacare.myapp.entity.Appointment;
import com.osacare.myapp.entity.AppointmentPayment;
import com.osacare.myapp.entity.PatientProfile;
import com.osacare.myapp.entity.User;
import com.osacare.myapp.entity.VitalSign;
import com.osacare.myapp.repository.AppointmentPaymentRepository;
import com.osacare.myapp.repository.AppointmentRepository;
import com.osacare.myapp.repository.PatientProfileRepository;
import com.osacare.myapp.repository.VitalSignRepository;
import com.osacare.myapp.service.HospitalDetailsService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/vsop")
public class VsopController {

    private final HospitalDetailsService hospitalDetailsService;
    private final AppointmentRepository appointmentRepository;
    private final VitalSignRepository vitalSignRepository;
    private final PatientProfileRepository patientProfileRepository;
    private final AppointmentPaymentRepository appointmentPaymentRepository;

    public VsopController(HospitalDetailsService hospitalDetailsService, 
                          AppointmentRepository appointmentRepository,
                          VitalSignRepository vitalSignRepository,
                          PatientProfileRepository patientProfileRepository,
                          AppointmentPaymentRepository appointmentPaymentRepository) {
        this.hospitalDetailsService = hospitalDetailsService;
        this.appointmentRepository = appointmentRepository;
        this.vitalSignRepository = vitalSignRepository;
        this.patientProfileRepository = patientProfileRepository;
        this.appointmentPaymentRepository = appointmentPaymentRepository;
    }

    @GetMapping("/dashboard")
    public String vsopDashboard(HttpSession session, Model model) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null || !user.getRole().replace(" ", "").equalsIgnoreCase("vsop")) return "redirect:/login";

        model.addAttribute("name", user.getName());
        model.addAttribute("username", user.getUsername());
        model.addAttribute("hospitalDetails", hospitalDetailsService.getDetails());

        LocalDate today = LocalDate.now(ZoneId.of("Asia/Kolkata"));
        List<Appointment> todaysPaidAppointments = appointmentRepository.findByAppointmentDateAndPaymentStatus(today, "PAID");
        
        long pendingCount = todaysPaidAppointments.stream()
                .filter(appt -> ("SCHEDULED".equalsIgnoreCase(appt.getStatus()) || "WAITING".equalsIgnoreCase(appt.getStatus())) && appt.getTokenId() != null)
                .count();

        long loggedTodayCount = todaysPaidAppointments.stream()
                .filter(appt -> !"SCHEDULED".equalsIgnoreCase(appt.getStatus()) && !"WAITING".equalsIgnoreCase(appt.getStatus()) && !"CANCELLED".equalsIgnoreCase(appt.getStatus()))
                .count();

        // FETCH USER'S RECORDED VITALS FOR TODAY TO COUNT URGENT CASES
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = today.atTime(23, 59, 59);
        List<VitalSign> myVitalsToday = vitalSignRepository.findByRecordedByAndRecordedAtBetweenOrderByRecordedAtDesc(user, startOfDay, endOfDay);
        
        long urgentCount = myVitalsToday.stream()
                .filter(v -> Boolean.TRUE.equals(v.getIsUrgent()))
                .count();
                
        model.addAttribute("pendingCount", pendingCount);
        model.addAttribute("loggedTodayCount", loggedTodayCount); 
        model.addAttribute("urgentCount", urgentCount); 

        return "vsop/dashboard";
    }

    @GetMapping("/queue")
    public String viewQueue(HttpSession session, Model model) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null || !user.getRole().replace(" ", "").equalsIgnoreCase("vsop")) return "redirect:/login";

        model.addAttribute("name", user.getName());
        model.addAttribute("username", user.getUsername());
        model.addAttribute("hospitalDetails", hospitalDetailsService.getDetails());

        LocalDate today = LocalDate.now(ZoneId.of("Asia/Kolkata"));
        
        List<Appointment> pendingQueue = appointmentRepository.findByAppointmentDateAndTokenIdIsNotNullOrderByTokenGeneratedAtAsc(today).stream()
                .filter(appt -> "WAITING".equalsIgnoreCase(appt.getStatus()) || "SCHEDULED".equalsIgnoreCase(appt.getStatus()))
                .collect(Collectors.toList());

        model.addAttribute("patientsQueue", pendingQueue);
        return "vsop/queue";
    }

    @GetMapping("/scanner")
    public String openScanner(HttpSession session, Model model) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null || !user.getRole().replace(" ", "").equalsIgnoreCase("vsop")) return "redirect:/login";

        model.addAttribute("name", user.getName());
        model.addAttribute("username", user.getUsername());
        model.addAttribute("hospitalDetails", hospitalDetailsService.getDetails());
        return "vsop/scanner";
    }

    @GetMapping("/api/appointment/scan")
    @ResponseBody
    public ResponseEntity<?> getAppointmentDetailsScan(@RequestParam String tokenId,
                                                       @RequestParam(required = false) String patientId,
                                                       HttpSession session) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null || !user.getRole().replace(" ", "").equalsIgnoreCase("vsop")) return ResponseEntity.status(403).build();

        AppointmentPayment payment = appointmentPaymentRepository.findByTokenId(tokenId.trim());
        
        if (payment == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "Invalid Token: No payment record found."));
        }

        Appointment appt = payment.getAppointment();
        if (appt == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "Appointment Not Found for this Token."));
        }

        // EXPIRATION VALIDATION RULE: Token is ONLY valid for the exact appointment date
        LocalDate today = LocalDate.now(ZoneId.of("Asia/Kolkata"));
        if (appt.getAppointmentDate() != null) {
            if (appt.getAppointmentDate().isBefore(today)) {
                return ResponseEntity.badRequest().body(Map.of("error", "Token EXPIRED: This token was only valid on " + 
                        appt.getAppointmentDate().format(DateTimeFormatter.ofPattern("dd MMM yyyy")) + " and cannot be used today."));
            }
            if (appt.getAppointmentDate().isAfter(today)) {
                return ResponseEntity.badRequest().body(Map.of("error", "Token Invalid: This token is for a future date (" + 
                        appt.getAppointmentDate().format(DateTimeFormatter.ofPattern("dd MMM yyyy")) + ")."));
            }
        }

        if (patientId != null && !patientId.trim().isEmpty()) {
            if (!patientId.trim().equals(appt.getPatient().getUsername())) {
                return ResponseEntity.badRequest().body(Map.of("error", "Patient ID mismatch. Invalid QR Code."));
            }
        }

        PatientProfile profile = patientProfileRepository.findByUser(appt.getPatient());
        
        String ageYYMMDD = "N/A";
        String gender = "N/A";

        if (profile != null) {
            if (profile.getDateOfBirth() != null) {
                Period p = Period.between(profile.getDateOfBirth(), LocalDate.now(ZoneId.of("Asia/Kolkata")));
                ageYYMMDD = String.format("%02d-%02d-%02d", p.getYears(), p.getMonths(), p.getDays());
            } else if (profile.getBirthYear() != null) {
                ageYYMMDD = (LocalDate.now(ZoneId.of("Asia/Kolkata")).getYear() - profile.getBirthYear()) + "-00-00";
            }
            gender = profile.getGender() != null ? profile.getGender() : "N/A";
        }

        VitalSign existingVital = vitalSignRepository.findByAppointmentId(appt.getId());

        Map<String, Object> data = new HashMap<>();
        data.put("id", appt.getId()); 
        data.put("tokenId", tokenId); 
        data.put("patientId", appt.getPatient().getUsername()); 
        data.put("patientName", appt.getPatient().getName());
        data.put("age", ageYYMMDD);
        data.put("gender", gender);
        data.put("doctorName", appt.getDoctor().getName());
        data.put("department", appt.getDepartment());
        data.put("appointmentDate", appt.getAppointmentDate() != null ? appt.getAppointmentDate().toString() : "N/A");
        data.put("appointmentTime", appt.getAppointmentTime() != null ? appt.getAppointmentTime() : "N/A");
        data.put("vitalsCaptured", existingVital != null); 
        
        if (existingVital != null && existingVital.getRecordedAt() != null) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy - hh:mm a");
            data.put("lastCapturedAt", existingVital.getRecordedAt().format(formatter));
        }

        return ResponseEntity.ok(data);
    }

    @PostMapping("/refresh-queue")
    public String refreshQueue(HttpSession session, RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null || !user.getRole().replace(" ", "").equalsIgnoreCase("vsop")) return "redirect:/login";

        redirectAttributes.addFlashAttribute("successMessage", "Queue successfully synced with latest payments.");
        return "redirect:/vsop/queue"; 
    }

    @GetMapping("/capture/{id}")
    public String showCaptureForm(@PathVariable Long id, HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null || !user.getRole().replace(" ", "").equalsIgnoreCase("vsop")) return "redirect:/login";

        Appointment appointment = appointmentRepository.findById(id).orElse(null);
        
        // FIX: Allow VSOP to update vitals even if Consultation is completed (COMPLETED) or in reception (IN_RECEPTION)
        if (appointment == null || (!"SCHEDULED".equalsIgnoreCase(appointment.getStatus()) 
                                    && !"WAITING".equalsIgnoreCase(appointment.getStatus()) 
                                    && !"WAITING_FOR_DOCTOR".equalsIgnoreCase(appointment.getStatus())
                                    && !"COMPLETED".equalsIgnoreCase(appointment.getStatus())
                                    && !"IN_RECEPTION".equalsIgnoreCase(appointment.getStatus()))) {
            return "redirect:/vsop/queue";
        }

        // EXPIRATION VALIDATION RULE: Prevent direct link access for expired tokens
        LocalDate today = LocalDate.now(ZoneId.of("Asia/Kolkata"));
        if (appointment.getAppointmentDate() != null && !appointment.getAppointmentDate().isEqual(today)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Cannot capture vitals: The token/appointment is not valid for today's date.");
            return "redirect:/vsop/queue";
        }

        PatientProfile profile = patientProfileRepository.findByUser(appointment.getPatient());
        String ageYYMMDD = "N/A";
        String gender = "N/A";

        if (profile != null) {
            if (profile.getDateOfBirth() != null) {
                Period p = Period.between(profile.getDateOfBirth(), LocalDate.now(ZoneId.of("Asia/Kolkata")));
                ageYYMMDD = String.format("%02d-%02d-%02d", p.getYears(), p.getMonths(), p.getDays());
            } else if (profile.getBirthYear() != null) {
                ageYYMMDD = (LocalDate.now(ZoneId.of("Asia/Kolkata")).getYear() - profile.getBirthYear()) + "-00-00";
            }
            gender = profile.getGender() != null ? profile.getGender() : "N/A";
        }

        AppointmentPayment payment = appointmentPaymentRepository.findByAppointment(appointment);
        String serviceToken = (payment != null && payment.getTokenId() != null) ? payment.getTokenId() : "N/A";

        VitalSign existingVital = vitalSignRepository.findByAppointmentId(appointment.getId());

        model.addAttribute("name", user.getName());
        model.addAttribute("username", user.getUsername());
        model.addAttribute("hospitalDetails", hospitalDetailsService.getDetails());
        model.addAttribute("appointment", appointment);
        model.addAttribute("patientAge", ageYYMMDD);
        model.addAttribute("patientGender", gender);
        model.addAttribute("serviceToken", serviceToken); 
        
        model.addAttribute("vitalSign", existingVital != null ? existingVital : new VitalSign());
        model.addAttribute("isUpdate", existingVital != null);

        return "vsop/capture";
    }

    @PostMapping("/capture/{id}")
    public String submitVitals(@PathVariable Long id, 
                               @ModelAttribute VitalSign vitalSign, 
                               @RequestParam(value = "isUrgent", required = false, defaultValue = "false") boolean isUrgent,
                               HttpSession session, 
                               RedirectAttributes redirectAttributes) {
                                   
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null || !user.getRole().replace(" ", "").equalsIgnoreCase("vsop")) return "redirect:/login";

        Appointment appointment = appointmentRepository.findById(id).orElse(null);
        LocalDate today = LocalDate.now(ZoneId.of("Asia/Kolkata"));
        
        if (appointment != null && appointment.getAppointmentDate() != null && !appointment.getAppointmentDate().isEqual(today)) {
            redirectAttributes.addFlashAttribute("error", "Error: The token is expired or invalid for today's date.");
            return "redirect:/vsop/scanner";
        }
        
        // FIX: Allow submission for COMPLETED and IN_RECEPTION as well
        if (appointment != null && ("SCHEDULED".equalsIgnoreCase(appointment.getStatus()) 
                                    || "WAITING".equalsIgnoreCase(appointment.getStatus()) 
                                    || "WAITING_FOR_DOCTOR".equalsIgnoreCase(appointment.getStatus())
                                    || "COMPLETED".equalsIgnoreCase(appointment.getStatus())
                                    || "IN_RECEPTION".equalsIgnoreCase(appointment.getStatus()))) {
            
            VitalSign existing = vitalSignRepository.findByAppointmentId(appointment.getId());
            boolean isUpdate = (existing != null);

            if (isUpdate) {
                existing.setBloodPressure(vitalSign.getBloodPressure());
                existing.setHeartRate(vitalSign.getHeartRate());
                existing.setTemperature(vitalSign.getTemperature());
                existing.setSpo2(vitalSign.getSpo2());
                existing.setRespiratoryRate(vitalSign.getRespiratoryRate());
                existing.setHeight(vitalSign.getHeight());
                existing.setWeight(vitalSign.getWeight());
                existing.setNotes(vitalSign.getNotes());
                existing.setIsUrgent(isUrgent); 
                existing.setRecordedBy(user); 
                vitalSign = existing;
            } else {
                vitalSign.setId(null); 
                vitalSign.setAppointment(appointment);
                vitalSign.setPatient(appointment.getPatient());
                vitalSign.setRecordedBy(user);
                vitalSign.setIsUrgent(isUrgent); 
            }

            AppointmentPayment payment = appointmentPaymentRepository.findByAppointment(appointment);
            if (payment != null) {
                vitalSign.setServiceTokenId(payment.getTokenId());
            }

            if (vitalSign.getHeight() != null && vitalSign.getWeight() != null && vitalSign.getHeight() > 0) {
                double heightM = vitalSign.getHeight() / 100.0;
                double calculatedBmi = vitalSign.getWeight() / (heightM * heightM);
                vitalSign.setBmi(Math.round(calculatedBmi * 100.0) / 100.0);
            }
            
            vitalSignRepository.save(vitalSign);

            // FIX: Do not override status back to WAITING_FOR_DOCTOR if the doctor has already completed it.
            if (!"COMPLETED".equalsIgnoreCase(appointment.getStatus()) && !"IN_RECEPTION".equalsIgnoreCase(appointment.getStatus())) {
                appointment.setStatus("WAITING_FOR_DOCTOR");
            }
            appointment.setUrgent(isUrgent); 
            appointmentRepository.save(appointment);

            String successMsg = isUpdate ? "Vitals updated successfully for " : "Vitals captured successfully for ";
            redirectAttributes.addFlashAttribute("successMessage", successMsg + appointment.getPatient().getName() + ".");
        } else {
            redirectAttributes.addFlashAttribute("error", "Error capturing vitals. Patient may have been processed already.");
        }

        return "redirect:/vsop/scanner"; // Returning via PRG pattern
    }

    @GetMapping("/logged-vitals")
    public String viewLoggedVitals(
            @RequestParam(required = false) String date,
            @RequestParam(required = false) String department,
            @RequestParam(required = false) Long doctorId,
            HttpSession session, Model model) {
        
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null || !user.getRole().replace(" ", "").equalsIgnoreCase("vsop")) return "redirect:/login";

        LocalDate filterDate = (date != null && !date.isEmpty()) ? LocalDate.parse(date) : LocalDate.now(ZoneId.of("Asia/Kolkata"));
        
        LocalDateTime startOfDay = filterDate.atStartOfDay();
        LocalDateTime endOfDay = filterDate.atTime(23, 59, 59);

        List<VitalSign> dailyVitals = vitalSignRepository.findByRecordedByAndRecordedAtBetweenOrderByRecordedAtDesc(user, startOfDay, endOfDay);

        List<String> departments = dailyVitals.stream()
                .map(v -> v.getAppointment().getDepartment())
                .distinct()
                .collect(Collectors.toList());

        List<User> doctors = dailyVitals.stream()
                .map(v -> v.getAppointment().getDoctor())
                .distinct()
                .collect(Collectors.toList());

        List<VitalSign> filteredVitals = dailyVitals.stream()
                .filter(v -> department == null || department.isEmpty() || v.getAppointment().getDepartment().equalsIgnoreCase(department))
                .filter(v -> doctorId == null || v.getAppointment().getDoctor().getId().equals(doctorId))
                .collect(Collectors.toList());

        model.addAttribute("name", user.getName());
        model.addAttribute("username", user.getUsername());
        model.addAttribute("hospitalDetails", hospitalDetailsService.getDetails());
        model.addAttribute("role", user.getRole());
        
        model.addAttribute("vitals", filteredVitals);
        
        model.addAttribute("selectedDate", filterDate.toString());
        model.addAttribute("selectedDept", department);
        model.addAttribute("selectedDoctor", doctorId);
        model.addAttribute("departments", departments);
        model.addAttribute("doctors", doctors);

        return "vsop/logged-vitals";
    }
}