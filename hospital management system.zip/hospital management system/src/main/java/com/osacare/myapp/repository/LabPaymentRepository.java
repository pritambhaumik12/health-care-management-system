package com.osacare.myapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.osacare.myapp.entity.LabPayment;

@Repository
public interface LabPaymentRepository extends JpaRepository<LabPayment, Long> {
}