package com.osacare.myapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.osacare.myapp.entity.LabService;

@Repository
public interface LabServiceRepository extends JpaRepository<LabService, Long> {
    
    // Fetch all lab services ordered alphabetically by service name
    List<LabService> findAllByOrderByServiceNameAsc();
}